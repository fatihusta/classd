///////////////////////////////////////////////////////////////////////////////
// This example application lets you set a scoring offset for a directory of
// messages.
//
// Syntax: sctrain -D <configdir> [OPTION] <directory>
// Train the SpamCatcher SDK with ham and spam messages.
//
// Arguments:  
//  configdir - Required. Directory containing rules and spamcatcher.conf
//			Database will be stored in this directory.
//  directory - Required. Directory containing mail messages

// Options:
//  -forget  
//		Optional. Specify this if you wish to remove the scoring offset
//		set previously. By default, sctrain will add the messages to its
//		database.
//  -o <offset>	  
//		Optional.  If you are adding messages, specify the scoring 
//		offset	as this parameter. The value should be between -200 
//		and 200. -200 will cause the message to be treated as approved 
//		while 200 will cause it to be treated as blocked.
//  -score
//		Optional. Compute scores of messages and factor them into future
//		scoring of messages from the senders.
//  -v  
//		Optional. Flag to output status of add and delete operations.
//	-clear
//		Optional. Remove all entries. Files will be deleted from the 
//		configuration directory.
//	-max_word_entries
//		Optional. Maximum entries for word training. Default is 1000000
//  -help
//		Show syntax.
//	-spam
//		Optional. Indicates message is spam. Equivalent to specifying "-o 200"
//  -ham 
//		Optional. Indicates message is not spam. Equivalent to specifying "-o -200"
//  -training_write_buffer 
//		Optional. Number of messages processed before history data is saved to disk.
//		This is purely for performance to avoid unnecessarily writing to disk
//		if you are training on a large set of messages.
//
// Examples:
//
// Example 1:  sctrain -D conf -ham messagedir
//  This approves all messages in the directory named messagedir.
//
// Example 2: sctrain -D conf -score dir2
//  This computes scores of messages in directory dir2.  If the messages were 
//  sent by the recipients of approved messages (as set by Example 1) 
//  then these scores will be used in the analysis of future messages from those
//  senders. This can help reduce false positives.
// 
// Example 3: sctrain -D conf -forget messagedir
//  Forget about messages in a directory.
// 
// Example 4: sctrain -D conf -clear
//	Clear the database. All data set by previous calls to addMessage and
//	addAddress along with scoring history will be deleted.
///////////////////////////////////////////////////////////////////////////////
#pragma warning(disable: 4786) // identifier was truncated to '255' characters
#ifdef WIN32
#include <io.h>
#include <windows.h>
#else
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <mailshell.h>
#include <vector>

#include <iostream>
#include <fstream>
#include <ctime>

Mailshell* engine;
bool verbose = false;
const int MAX_MSG_SIZE=20000;

using namespace std;

void usage() {
	cout << "Syntax: sctrain -D <configdir> [OPTION] <directory>" << endl;
	cout << "Train the SpamCatcher SDK with ham and spam messages." << endl;
	cout << "" << endl;
	cout << "Arguments:" << endl;
	cout << "configdir - Required. Directory containing rules and spamcatcher.conf" << endl;
	cout << "	Database will be stored in this directory." << endl;
	cout << "directory - Required. Directory containing mail messages" << endl;
	cout << "" << endl;
	cout << "Options:" << endl;
	cout << "-forget" << endl;
	cout << "	Optional. Specify this if you wish to remove the scoring offset" << endl;
	cout << "	set previously. By default, sctrain will add the messages to its" << endl;
	cout << "	database." << endl;
	cout << "-o <offset>" << endl;
	cout << "	Optional.  If you are adding messages, specify the scoring" << endl;
	cout << "	offset	as this parameter. The value should be between -200" << endl;
	cout << "	and 200. -200 will cause the message to be treated as approved" << endl;
	cout << "	while 200 will cause it to be treated as blocked." << endl;
	cout << "-score" << endl;
	cout << "	Optional. Compute scores of messages and factor them into future" << endl;
	cout << "	scoring of messages from the senders." << endl;
	cout << "-v" << endl;
	cout << "	Optional. Flag to output status of add and delete operations." << endl;
	cout << "-spam" << endl;
	cout << "	Optional.  Indicates message is spam. Equivalent to specifying -o 200" << endl;
	cout << "-ham"  << endl;
	cout << "	Optional. Indicates message is not spam. Equivalent to specifying -o -200"  << endl;
	cout << "-clear" << endl;
	cout << "	Optional. Remove all entries. Files will be deleted from the " << endl;
	cout << "	configuration directory." << endl;
	cout << "-max_word_entries" <<endl;
	cout << "   Optional. Maximum word entries when using training. Default is 1000000." << endl;
	cout << "-training_write_buffer" << endl;
	cout << "	Optional. Number of messages processed before history data is saved to disk." << endl;
	cout << "-help" << endl;
	cout << "	Show syntax." << endl;
	cout << "\nExamples:\n" << endl;
	cout << "Example 1:  sctrain -D conf -ham messagedir" << endl;
	cout << "This approves all messages in the directory named messagedir." << endl;
	cout << "\nExample 2: sctrain -D conf -score dir2" << endl;
	cout << "This computes scores of messages in directory dir2.  If the messages were " << endl;
	cout << "sent by the recipients of approved messages (as set by Example 1)"  << endl;
	cout << "then these scores will be used in the analysis of future messages from those" << endl;
	cout << "senders. This can help reduce false positives." << endl;
	cout << "\nExample 3: sctrain -D conf -forget messagedir"  << endl;
	cout << "Forget about messages in a directory."  << endl;
	cout << "\nExample 4: sctrain -D conf -clear"  << endl;
	cout << "Clear the database. All data set by previous calls to addMessage and" << endl;
	cout << "addAddress along with scoring history will be deleted." << endl;

	exit(0);
}

// Add or delete a message
// Arguments: 
// file - Full path to a file
// add  - true to add a message and offset, false to remove
// offset - How to adjust scoring. 
// This should be a value between -200 and 200.
// useScores - true if a score should be computed. This may be used in
// computing future scores of messages from the same sender.
// signedSender - outgoing message from trusted sender
// Returns: true of successful, false, otherwise.
bool processMessage(string file, bool add = true, int offset = 0, 
					bool useScores = false,  int signedSender = 0)
{
	char buf[MAX_MSG_SIZE];

	// read the file in.
	FILE *fp;

	if ((fp = fopen(file.c_str(), "rb"))) {
		int bufLen=0;
		while (!feof(fp) && (bufLen < MAX_MSG_SIZE) ) {
			int chunk = MAX_MSG_SIZE - bufLen;
			bufLen += fread(buf+bufLen, 1, chunk, fp);
		}
		fclose(fp);

		int result = 0;

		if (add) 
		{
			result = engine->addMessage(offset, buf, bufLen, signedSender);
			if (verbose)
				cout << "adding " << file << " with offset " << offset << " got " << result << endl;

			if (useScores) // build up history
			{
				unsigned int score;
				engine->computeScore(buf, bufLen, &score);
			}
		}
		else
		{
			if (verbose)
				cout << "deleting " << file << endl;
			result = engine->deleteMessage((const char*)buf, (unsigned int)bufLen);
		}
		if (result == MAILSHELL_OK)
			return true;
		else
			return false;
	}
	return false;
}

int main (int argc, char **argv) 
{
	string confdir = ".";
	vector <string> leftoverargs;

	// Parse command line options
	// -D 
	int i=0;

	int offset = 0; // value to pass to addMessage
	bool add = true; // whether to add to database.
	bool useScores = false;
	bool clearDB = false; // whether to delete all entries.
	bool ham = false;
	bool spam = false;
	char *trainingWriteBuffer = NULL;
	char *maxWordEntriesBuffer = NULL;

	for (i=1; i < argc; i++) {
		string arg = argv[i];

		if (arg=="-D") {
			i++;
			if (i>=argc) usage();
			confdir = argv[i];
		} 
		else if (arg == "-o") {
			i++;
			if (i>=argc) usage();
			offset = atoi(argv[i]);
		}
		else if (arg == "-forget") { // remove messages from database
			add = false;			
		} else if (arg == "-v") {
			verbose = true;
		}
		else if (arg == "-score") { 
			useScores = true;
		}
		else if (arg == "-clear") {
			clearDB = true;
		}
		else if (arg == "-help") {
			usage();
			exit(0);
		}
		else if (arg == "-ham") {
			ham = true;
		}
		else if (arg == "-spam") {
			spam = true;
		}
		else if (arg == "-max_word_entries") {
			i++;
			if (i>=argc) usage();
			maxWordEntriesBuffer = argv[i];
		}
		else if (arg == "-training_write_buffer") {
			i++;
			if (i>=argc) usage();
			trainingWriteBuffer = argv[i];
		}
		else {
			leftoverargs.push_back(argv[i]);
		}
	}


	if (argc == 1 || confdir == "." || (ham && spam)) {
		usage();
		exit(0);
	}

	// remove all old entries
	if (clearDB) {
#ifdef WIN32
		string fname = confdir + "\\" + "scoffset.bin.full";
#else
		string fname = confdir + "/" + "scoffset.bin.full";
#endif
		FILE *fp = fopen(fname.c_str(), "w");
		if (fp)
			fclose(fp);

#ifdef WIN32
		fname = confdir + "\\" + "scoffset.bin.incr";
#else
		fname = confdir + "/" + "scoffset.bin.incr";
#endif
		fp = fopen(fname.c_str(), "w");
		if (fp)
			fclose(fp);

#ifdef WIN32
		fname = confdir + "\\" + "scrh.bin.full";
#else
		fname = confdir + "/" + "scrh.bin.full";
#endif

		fp = fopen(fname.c_str(), "w");
		if (fp)
			fclose(fp);

#ifdef WIN32
		fname = confdir + "\\" + "scwh.bin.full";
#else
		fname = confdir + "/" + "scwh.bin.full";
#endif

		fp = fopen(fname.c_str(), "w");
		if (fp)
			fclose(fp);

		printf("database has been reset.\n");
		exit(0);
	}
	

	if (ham)
		offset = -200;
	else if (spam)
		offset = 200;

	// 
	if (leftoverargs.empty()) {
		cout << "Specify a directory containing messages." <<endl;
		exit(255);
	}

	time_t startTime = time(0);
	cout << "current time is: " << ctime(&startTime) <<endl;
	

	cout << "Instantiating engine" << endl;
	engine = new Mailshell(confdir.c_str());
	cout << "done" << endl;


	char vbuf[40];
	unsigned int vbufSize = 40;

	// determine Mailshell SDK version
	engine->getVersion(vbuf, &vbufSize);

	cout << "SDK version: " << vbuf << endl;

	int msgnum=0;

	cout << endl << "Initializing Mailshell SpamCatcher . . . \n";

	int rc;
	rc = engine->setOption("use_score_offsets", "yes");
	rc = engine->setOption("enable_sender_training", "yes");
	rc = engine->setOption("enable_rules", "yes");
	rc = engine->setOption("enable_rule_training", "yes");
	rc = engine->setOption("track_rule_performance", "yes");
	rc = engine->setOption("enable_word_training", "yes");
	rc = engine->setOption("enable_country_training", "yes");

	if (trainingWriteBuffer)
		rc = engine->setOption("training_write_buffer", trainingWriteBuffer);

	if (maxWordEntriesBuffer) {
		rc = engine->setOption("max_word_entries", maxWordEntriesBuffer);
	} else {
		rc = engine->setOption("max_word_entries", "1000000");
	}

	rc = engine->initialize();
	cout << "Done" <<endl<<endl;
	switch(rc) {
	case MAILSHELL_OK:
		break;
	case MAILSHELL_LICENSE_INVALID:
		cout << "ERROR: Mailshell License is invalid." << endl;
		exit(6);
		break;
	case MAILSHELL_LICENSE_EXPIRED:
		cout << "ERROR: Mailshell License is expired." << endl;
		exit(6);
		break;
	case MAILSHELL_INVALID_CONFIG_DIR:
		cout << "ERROR: Invalid Configuration Directory." << endl;
		exit(6);
		break;
	case MAILSHELL_NO_RULES_LOADED:
		cout << "ERROR: No Rules Loaded." << endl;
		exit(6);
		break;
	default: 
		cout << "ERROR: Unknown Error occurred." << endl;
		exit(6);
		break;
	}

	int totalMsgs=0;

#ifdef WIN32
	DWORD64 totalBytes = 0;
#else
	off_t totalBytes = 0;
#endif

	time_t initTime = time(0);
	cout << "initialization completed at: " << ctime(&initTime) <<endl;

	int signedSender = 0;
	if (offset == -200)
		signedSender = 1;
	
	for (vector<string>::iterator it = leftoverargs.begin();
		 it != leftoverargs.end();
		 ++it) {
		string dirname = (*it);

#ifdef WIN32
		_finddata_t c_file;
		long hFile;
		string fname;

		string specifier = dirname + "\\*.*";
		if( (hFile = _findfirst(specifier.c_str(),&c_file))==-1)
			continue;
		
		while( _findnext( hFile, &c_file ) == 0 )
		{
			int childIndex=-1;
			if (c_file.attrib & _A_SUBDIR) 
				continue;

			fname = dirname + "\\" + c_file.name;

			totalBytes += c_file.size;

#else			
		DIR *thedir = opendir(dirname.c_str());
		if (!thedir) continue;
		
		struct dirent *de;
		cerr << "Opening Directory: " << dirname.c_str() << endl;

		while (de=readdir(thedir)) {
			int childIndex=-1;
			string fname = de->d_name;
			fname = dirname + "/" + fname;
			
			struct stat statbuf;
			stat(fname.c_str(),&statbuf);
			if (S_ISDIR(statbuf.st_mode)) continue;

			totalBytes += statbuf.st_size;

#endif

			processMessage(fname, add, offset, useScores, signedSender);
			totalMsgs++;
		}
#ifdef WIN32
			_findclose( hFile );
#else
			closedir(thedir);
#endif
		
	}

		
	if (engine) delete engine;
	// get the new time
	time_t endTime;
	time(&endTime);

	cout << "current time is now: " << ctime(&endTime) <<endl;

	double elapsed = difftime(initTime, startTime);
	cout << "time to initialize: " <<  elapsed << " seconds" << endl;

	elapsed = difftime(endTime, initTime);
	cout << "time to process directory: " <<  elapsed << " seconds" << endl;

	exit(0);
	return 0;
}

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <fcntl.h>
#include <errno.h>

#if defined (WIN32)
	#include "wingetopt.h"
	#include "winsock2.h"
	#include <Shlwapi.h>

	#define PATH_MAX MAX_PATH
	#define sleep(a) Sleep( a * 1000 )
	static void getcwd(char * buf, int size) { GetCurrentDirectoryA(size, buf); }
#else
	#include <getopt.h>
	#include <unistd.h>
    #include <sys/ipc.h>
    #include <sys/shm.h>
#endif

#include "bdamclient.h"


static const char * copyright = "BitDefender bdavclient, Copyright (C) BitDefender SRL 2009-2017";
static int print_filename = 1;

// A simple ctime-like conversion helper which uses a static buffer (so using it in multiple arguments is NOT supported)
static const char * timeToString( time_t t, const char * format = "%Y-%m-%d %H:%M:%S" )
{
    static char buf[1024];

    if ( t <= 0 )
        strcpy( buf, "N/A" );
    else
        strftime( buf, sizeof(buf), format, localtime (&t) );

    return buf;
}

static void show_usage ( char *exename )
{
	fprintf( stderr,
		"%s\n"
		"Usage: %s -p <path/port> -i\n"
		"       %s -p <path/port> [options] <file1> [file2...]\n"
		"Options:\n"
        "   -p port/path specifies addr:port (TCP/IP) or path (Unix socket) of anti-malware server to connect. Defaults to 127.0.0.1:1344\n"
        "   -i           shows information about anti-malware server in a human-readable format\n"
        "   -m           shows information about anti-malware server in a script readable format\n"
        "   -u           forces the server to attempt to update the databases immediately\n"
        "   -R           forces the database reload\n"
        "   -r           forces the remote scan, sending the file content via the socket\n"
#if !defined (WIN32)
        "   -s           forces the scan via shared memory\n"
        "   -d           forces the scan via open file descriptor\n"
#endif
        "   -e <pattern> print all the virus records in database matching pattern' use * for all\n"
        "   -l <url>     scan the URL\n"
        "   -b <file>    directly submit the file into Bitdefender sandbox and wait for result\n"
		"   -o <options> list of scanning options, see below\n"
		"   -h           show this help and exit\n\n"
		"Scanning options (to use with -o):\n"
		"        a       enable archives scanning\n"
		"        p       enable packed files scanning\n"
		"        d       enable disinfection\n"
		"        e       enable e-mail database scanning\n"
        "        b       enable hyper-detection\n"
		"        v       print scan progress\n"
		"        s       instruct the server to also scan for spam/phishing if enabled in the server\n"
		"        n       do not print file name in progress and result messages\n",
  		copyright, exename, exename  );
}

static char * status_to_output(int status, const char * threatname, int threattype)
{
	static char buf[512];
	const char * typetxt = "unknown";
	
	switch ( threattype )
	{
		case BDAM_THREAT_TYPE_VIRUS:
			typetxt = "virus";
			break;
			
		case BDAM_THREAT_TYPE_SPYWARE:
			typetxt = "spyware app";
			break;

		case BDAM_THREAT_TYPE_ADWARE:
			typetxt = "adware app";
			break;

		case BDAM_THREAT_TYPE_DIALER:
			typetxt = "dialer app";
			break;

		case BDAM_THREAT_TYPE_APP:
			typetxt = "potentially dangerous app";
			break;

		case BDAM_THREAT_TYPE_SPAM:
			typetxt = "spam email";
			break;

		case BDAM_THREAT_TYPE_PHISHING:
			typetxt = "phishing email";
			break;

        case BDAM_THREAT_TYPE_NEEDSANDBOX:
            typetxt = "need-to-sandbox";
            break;
	}
	
	switch ( status )
	{
		case BDAM_SCANRES_CLEAN:
			strcpy( buf, "CLEAN" );
			break;
			
		case BDAM_SCANRES_INFECTED:
			sprintf( buf, "INFECTED %s %s", typetxt, threatname ? threatname : "NULL");
			break;

		case BDAM_SCANRES_SUSPICIOUS:
			sprintf( buf, "SUSPICION %s", threatname ? threatname : "NULL");
			break;

		case BDAM_SCANRES_ENCRYPTED:
			strcpy( buf, "ENCRYPTED" );
			break;

		case BDAM_SCANRES_CORRUPTED:
			strcpy( buf, "CORRUPTED" );
			break;

		case BDAM_SCANRES_DISINFECTED:
			sprintf( buf, "DISINFECTED %s %s", typetxt, threatname ? threatname : "NULL");
			break;

		case BDAM_SCANRES_DISINFECTFAILED:
			sprintf( buf, "DISINFECTFAILED %s %s", typetxt, threatname ? threatname : "NULL");
			break;

		case BDAM_SCANRES_INCOMPLETE:
			strcpy( buf, "FAILED" );
			break;
	}
	
	return buf;
}


static void client_callback(const char * filename, int status, const char * threatname, int threattype, void *)
{
	if ( print_filename )
		printf("-%s %s\n", filename, status_to_output(status, threatname, threattype) );
	else
		printf("-%s\n", status_to_output(status, threatname, threattype) );
}

static void malware_name_callback(const char * name, void * ctx)
{
    (*((int*)ctx))++;
    printf( "%s\n", name );
}

#if !defined (WIN32)
static int scan_shared_memory_file( BDAMClient * client, const char * filepath, int *scanStatus, int * threatType, const char **threatName )
{
    int err = -1;
    off_t size;
    int shmkey = 938423; // some random number
    int shmid = -1;
    void * shmaddr = (void*) -1;

    int fd = open( filepath, O_RDONLY );

    if ( fd < 0 )
    {
        fprintf( stderr, "Error opening file %s: %s\n", filepath, strerror(errno) );
        return 1;
    }

    // Get file size
    size = lseek(fd, 0, SEEK_END);
    lseek(fd, 0, SEEK_SET);

    if ( size <= 0 )
    {
        fprintf( stderr, "Error getting size of file %s: %s\n", filepath, strerror(errno) );
        goto done;
    }

    if ( (shmid = shmget(shmkey, size, IPC_CREAT | 0666)) == -1
         || (shmaddr = shmat(shmid, NULL, 0) ) == (void *) -1 )
    {
        fprintf( stderr, "Error creating/attaching shared memory segment of size %ld: %s\n", (long) size, strerror(errno) );
        goto done;
    }

    // Read the file there
    if ( read( fd, shmaddr, size) != size )
    {
        fprintf( stderr, "Error reading file %s: %s\n", filepath, strerror(errno) );
        goto done;
    }

    err = BDAMClient_ScanSharedMemory( client, (unsigned long) shmkey, (unsigned long) size, (unsigned long) size, scanStatus, threatType, threatName );

done:
    // Free the shared memory area
    if ( shmaddr != (void*) -1 )
        shmdt( shmaddr );

    // Free the shared memory ID
    if ( shmid != -1 )
        shmctl( shmid, IPC_RMID, NULL );

    close( fd );
    return err;
}
#endif

static int scan_in_sandbox( BDAMClient * client, const char * filename )
{
    // Send the file to sandbox
    char jobid[1024], boxresult[4096];

    int err = BDAMClient_SandboxSendFile( client, filename, jobid, sizeof(jobid) );

    if ( err != 0 )
    {
        fprintf( stderr, "Error sending file %s to sandbox: %d\n", filename, err );
        return 10;
    }

    printf("%s: submitted to sandbox, jobid %s\n", filename, jobid );

    // Check the status
    int status;

    while ( (err = BDAMClient_SandboxQueryJob( client, jobid, &status, boxresult, sizeof(boxresult) ) ) == 0 )
    {
        if ( status == BDAM_SCANRES_INCOMPLETE )
        {
            printf("... still pending\n");
            sleep ( 15 );
            continue;
        }

        if ( status == BDAM_SCANRES_CLEAN )
        {
            printf("The file %s is clean\n", filename );
            break;
        }
        else
        {
            // Replace all | by \n in result
            char * p;

            while ( ( p = strchr( boxresult, '|') ) != 0 )
                *p = '\n';

            printf("The file %s is infected. Threat info:\n%s\n", filename, boxresult );
            break;
        }
    }

    if ( err != 0 )
    {
        fprintf( stderr, "Error querying job id: %d\n", err );
        return 10;
    }

    return 0;
}


int main (int argc, char **argv)
{
    char * amserver_sock = strdup("127.0.0.1:1344"), * enum_pattern = 0;
    int err, opt, retcode = 0, showhinfo = 0, showsinfo = 0, startupdate = 0, remotescan = 0;
    int fdscan = 0, shmscan = 0, databasereload = 0, scanurl = 0, sendsandbox = 0;
	int scanoptions = 0;
	int use_progress_callback = 0;
#if defined (WIN32)
    static char * CMDOPTS = "lbhimRrup:o:e:";
#else
    static const char * CMDOPTS = "lbdhimrRusp:o:e:";
#endif

	// Parse the ccommand-line options
	while ((opt = getopt(argc, argv, CMDOPTS)) != -1)
	{
		switch (opt)
		{
			case 'h':
				show_usage( argv[0] );
				return 1;
			
            case 'l':
                scanurl = 1;
                break;

            case 'b':
                sendsandbox = 1;
                break;

			case 'i':
                showhinfo = 1;
				break;

            case 'm':
                showsinfo = 1;
                break;

            case 'u':
                startupdate = 1;
                break;

            case 'r':
                remotescan = 1;
                break;

            case 'R':
                databasereload = 1;
                break;

            case 'd':
                fdscan = 1;
                break;

            case 's':
                shmscan = 1;
                break;

			case 'p':
                free( amserver_sock );
				amserver_sock = strdup( optarg );
				break;

            case 'e':
                enum_pattern = strdup( optarg );
                break;

			case 'o':
				if ( strchr( optarg, 'a' ) != 0 )
					scanoptions |= BDAM_SCANOPT_ARCHIVES;

				if ( strchr( optarg, 'p' ) != 0 )
					scanoptions |= BDAM_SCANOPT_PACKED;

				if ( strchr( optarg, 'e' ) != 0 )
					scanoptions |= BDAM_SCANOPT_EMAILS;
				
				if ( strchr( optarg, 'd' ) != 0 )
					scanoptions |= BDAM_SCANOPT_DISINFECT;

				if ( strchr( optarg, 's' ) != 0 )
                    scanoptions |= BDAM_SCANOPT_SPAMCHECK;

                if ( strchr( optarg, 'b' ) != 0 )
                    scanoptions |= BDAM_SCANOPT_HAVESANDBOX;
				
				if ( strchr( optarg, 'n' ) != 0 )
					print_filename = 0;
				
				if ( strchr( optarg, 'v' ) != 0 )
					use_progress_callback = 1;

				break;

			case '?':
				printf ("Unrecognized option: %c\n", optopt );
				show_usage( argv[0] );
				return 1;
		}
	}

	// We need both -p and either -i or at least one command-line arg
	if ( !amserver_sock )
	{
		printf ("-p option is required\n" );
		return 1;
	}
		
    if (showhinfo == 0 && showsinfo == 0 && startupdate == 0 && databasereload  == 0 && (argc < 2 || optind == argc) && !enum_pattern )
	{
		show_usage( argv[0] );
		return 1;
	}

    if ( (scanoptions & BDAM_SCANOPT_HAVESANDBOX) && remotescan )
    {
        printf ("-r option is not compatible with -ob scanning option\n" );
        return 1;
    }

#if defined (WIN32)
	WSADATA wsadata;
	if (WSAStartup(0x202, &wsadata) != 0)
	{
		fprintf(stderr, "Winsock initialization failed");
		exit(1);
	}
#endif

	// Get a new client
	BDAMClient * client = BDAMClient_Create();
	
	if ( !client )
	{
		fprintf( stderr, "Error creating BitDefeinder client\n" );
		return 2;
	}
	
	// Set options
	if ( scanoptions && (err = BDAMClient_SetOption( client, scanoptions, 1 ) ) != 0 )
	{
		fprintf( stderr, "Error setting scan options: %d\n", err );
		return 5;
	}

	// Set callback
	if ( use_progress_callback )
	{
		if ( (err = BDAMClient_SetCallback( client, client_callback, 0 ) ) != 0 )
		{
			fprintf( stderr, "Error setting callback: %d\n", err );
			return 5;
		}
	}
	
	// Connect to the remote server
	if ( (err = BDAMClient_Connect( client, amserver_sock )) != 0 )
	{
		fprintf( stderr, "Error connecting to server at %s: %d\n", amserver_sock, err );
		return 3;
	}
	
    if ( startupdate )
    {
        if ( BDAMClient_StartUpdate( client ) != 0 )
        {
            fprintf( stderr, "Error sending UPDATE command to the server: %d\n", err );
            return 4;
        }

        printf("Update initiated successfully\n");
        return 0;
    }

    if ( scanurl )
    {
        // Scan URLs
        for ( int i = optind; i < argc; i++ )
        {
            char result[1024];

            err = BDAMClient_ScanURL( client, argv[i], result, sizeof( result ) );

            if ( err != 0 )
            {
                fprintf( stderr, "Error scanning URL %s: %d\n", argv[i], err );
                retcode = 10;
            }

            printf("%s: %s\n", argv[i], result );
        }

        return retcode;
    }


    if ( sendsandbox )
        return scan_in_sandbox( client, argv[optind] );

    if ( databasereload  )
    {
        if ( (err = BDAMClient_ReloadDatabase( client )) != 0 )
        {
            switch ( err )
            {
            case BDAM_ERROR_SYNTAXREPLY:
                fprintf( stderr, "Error 400 sending RELOAD command to the server: cannot use reload in this mode\n" );
                break;

            case BDAM_ERROR_SCAN_NOTFOUND:
                fprintf( stderr, "Error 401 sending RELOAD command to the server: no successful update yet\n" );
                break;

            case BDAM_ERROR_INVALIDOPTION:
                fprintf( stderr, "Error 402 sending RELOAD command to the server: already staged\n" );
                break;

            default:
                fprintf( stderr, "Error sending RELOAD command to the server: %d\n", err );
                break;
            }
            return 4;
        }

        printf("Reload requested successfully\n");
        return 0;
    }

	// If info is requested, ask for it
    if ( showsinfo || showhinfo )
	{
        time_t license_expiration_time, amdb_update_time;
        time_t update_attempted, update_succeed, update_performed;
        unsigned int currentver, update_errors;
        const char * enginever;

		unsigned long amdb_records;
		
		if ( (err = BDAMClient_Info( client, &license_expiration_time, &amdb_update_time, &amdb_records )) != 0 )
		{
            fprintf( stderr, "Error getting INFO information from server: %d\n", err );
			return 4;
		}

        if ( (err = BDAMClient_InfoUpdatesAV( client, &update_attempted, &update_performed, &update_succeed, &update_errors, &currentver, &enginever)) != 0 )
        {
            fprintf( stderr, "Error getting AV INFO information from server: %d\n", err );
            return 4;
        }

        // timeToString() does not support simultaneous usage, so we have multiple print statements to keep the sample code simple
        if ( showhinfo )
        {
            printf( "BitDefender Anti-malware service information:\n" );

            if ( strcmp( enginever, "UNKNOWN" ) )
            {
                printf( "  Anti-malware service is enabled\n" );
                printf( "  Anti-malware engine version: %s\n", enginever );
                printf( "  Anti-malware license expiration date: %s\n", timeToString( license_expiration_time ) );
                printf( "  Anti-malware database: %ld records\n", amdb_records );
                printf( "  Anti-malware database released at: %s\n", timeToString( amdb_update_time ) );
                printf( "  Anti-malware database last update attempted: %s\n", timeToString( update_attempted ) );
                printf( "  Anti-malware database last update succeed: %s\n", timeToString( update_succeed ) );
                printf( "  Anti-malware database last update which downloaded the new update: %s\n", timeToString( update_performed ) );
                printf( "  Anti-malware database update errors after last update: %d\n", update_errors );
                printf( "  Anti-malware database current version on the server: %d\n", currentver );
            }
            else
                printf( "  Anti-malware service is disabled\n" );
        }
        else
        {
            printf( "AV_ENGINE_VERSION %s\n", enginever );
            printf( "AV_LICENSE_EXPIRES %s\n", timeToString( license_expiration_time ) );
            printf( "AV_DB_TOTAL_RECORDS %ld\n", amdb_records );
            printf( "AV_DB_RELEASE_TIMESTAMP %s\n", timeToString( amdb_update_time ) );
            printf( "AV_DB_UPDATE_ATTEMPTED %s\n", timeToString( update_attempted ) );
            printf( "AV_DB_UPDATE_SUCCEED %s\n", timeToString( update_succeed ) );
            printf( "AV_DB_UPDATE_DOWNLOADED %s\n", timeToString( update_performed ) );
            printf( "AV_DB_UPDATE_ERRORS %d\n", update_errors );
            printf( "AV_DB_UPDATE_SERVER_VERSION %d\n", currentver );
        }

        if ( (err = BDAMClient_InfoUpdatesAS( client, &update_attempted, &update_performed, &update_succeed, &update_errors, &currentver, &enginever)) != 0 )
        {
            fprintf( stderr, "Error getting AS INFO information from server: %d\n", err );
            return 4;
        }

        if ( showhinfo )
        {
            printf( "BitDefender Anti-spam service information:\n" );

            if ( strcmp( enginever, "UNKNOWN" ) )
            {
                printf( "  Anti-spam service is enabled\n" );
                printf( "  Anti-spam engine version: %s\n", enginever );
                printf( "  Anti-spam database last update attempted: %s\n", timeToString( update_attempted ) );
                printf( "  Anti-spam database last update succeed: %s\n", timeToString( update_succeed ) );
                printf( "  Anti-spam database last update which downloaded the new update: %s\n", timeToString( update_performed ) );
                printf( "  Anti-spam database update errors after last update: %d\n", update_errors );
                printf( "  Anti-spam database current version on the server: %d\n", currentver );
            }
            else
                printf( "  Anti-spam service is disabled\n" );
        }
        else
        {
            printf( "AS_ENGINE_VERSION %s\n", enginever );
            printf( "AS_DB_UPDATE_ATTEMPTED %s\n", timeToString( update_attempted ) );
            printf( "AS_DB_UPDATE_SUCCEED %s\n", timeToString( update_succeed ) );
            printf( "AS_DB_UPDATE_DOWNLOADED %s\n", timeToString( update_performed ) );
            printf( "AS_DB_UPDATE_ERRORS %d\n", update_errors );
            printf( "AS_DB_UPDATE_SERVER_VERSION %d\n", currentver );
        }
	}

    // Enum records
    if ( enum_pattern )
    {
        int found = 0;

        if ( (err = BDAMClient_FindRecords( client, enum_pattern, malware_name_callback, &found )) != 0 )
        {
            fprintf( stderr, "Error enumerating the database records: %d\n", err );
            return 4;
        }

        printf( "--- %d found ---\n", found );
    }

	// Scan files
	for ( int i = optind; i < argc; i++ )
	{
		int status, threattype;
		const char * threatname;
		char filepath[PATH_MAX];

        // If the path is not absolute, make it absolute.
#if defined (WIN32)
        _fullpath( filepath, argv[i], sizeof(filepath) );
#else
		if ( argv[i][0] != '/' )
		{
			getcwd( filepath, sizeof(filepath) );
			strcat(filepath, "/");
			strcat( filepath, argv[i] );
		}
		else
            strcpy( filepath, argv[i] );
#endif

        // If both remote and fd scan is specified, use both
        if ( remotescan )
            err = BDAMClient_ScanSentObject( client, filepath, &status, &threattype, &threatname );
#if !defined (WIN32)
        else if ( shmscan )
        {
            err = scan_shared_memory_file( client, filepath, &status, &threattype, &threatname );

            if ( err != 0 )
                 retcode = 10;
        }
        else if ( fdscan )
        {
            int fd = open( filepath, O_RDONLY );

            if ( fd < 0 )
            {
                fprintf( stderr, "Error opening file %s: %s\n", filepath, strerror(errno) );
                err = 1;
                retcode = 10;
            }
            else
            {
                err = BDAMClient_ScanFileDescriptor( client, fd, &status, &threattype, &threatname );
                close( fd );
            }
        }
#endif // defined (WIN32)
        else
            err = BDAMClient_ScanFile( client, filepath, &status, &threattype, &threatname );
		
        if ( err != 0 )
		{
			fprintf( stderr, "Error scanning file %s: %d\n", filepath, err );
			retcode = 10;
		}
		else
		{
			if ( print_filename )
				printf( "%s: %s\n", filepath, status_to_output(status, threatname, threattype) );
			else
				printf( "%s\n", status_to_output(status, threatname, threattype) );
		}

        // For those files for which "need sandbox" was returned, scan them in sandbox
        if ( threattype == BDAM_THREAT_TYPE_NEEDSANDBOX )
            scan_in_sandbox( client, filepath );
	}


	return retcode;
}

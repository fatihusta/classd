#ifndef MAILSHELL_H
#define MAILSHELL_H

#include <time.h>

#define MAILSHELL_OK 0
#define MAILSHELL_INVALID_ARG 1001
#define MAILSHELL_INVALID_OPTION_KEY 1002
#define MAILSHELL_INVALID_OPTION_VALUE 1003
#define MAILSHELL_BUFFER_TOO_SMALL 1004
#define MAILSHELL_NO_MEMORY 1005
#define MAILSHELL_LICENSE_INVALID 1006
#define MAILSHELL_LICENSE_EXPIRED 1007
#define MAILSHELL_INVALID_CONFIG_DIR 1008
#define MAILSHELL_NO_RULES_LOADED 1009
#define MAILSHELL_LICENSE_OVERUSED 10010
#define MAILSHELL_RULES_NOT_RETRIEVED 10011
#define MAILSHELL_NETWORK_ERROR 10016
#define MAILSHELL_MERGE_FAILED 10017
#define MAILSHELL_RULES_UPTODATE 10018
#define MAILSHELL_ENGINE_UPTODATE 10019
#define MAILSHELL_INVALID_DLL 10020

#define MAILSHELL_DKIM_OK 0
#define MAILSHELL_DKIM_SIGNFAIL 1
#define MAILSHELL_DKIM_BAD_PARAM 2
#define MAILSHELL_DKIM_INVALID 3

#define TMP_FAIL 0
#define TMP_SUCCESS 1

#define GREYLIST_TMPFAIL 0
#define GREYLIST_PASS 1
#define GREYLIST_FULL 3

#define MAILSHELL_DKIM_CANON_SIMPLE 0
#define MAILSHELL_DKIM_CANON_RELAXED 1

#define MAILSHELL_DKIM_SIGN_RSASHA1 0
#define MAILSHELL_DKIM_SIGN_RSASHA256 1

class SCEngine;
class SCMessage;
class MailshellMsg;

#ifdef WIN32
#  ifdef HIDE_SDK_INTERFACE
#    define DllExport
#  else
#    define DllExport   __declspec( dllexport )
#  endif
#else
#  define DllExport
#endif

typedef int (*retrieve_progress_callback)(void *opaque, int ruleFileIndex, int dltotal,int dlnow,int ultotal,int ulnow);

class Mailshell
{
  friend class MailshellMsg;
  public:
    DllExport Mailshell(const char* config_dir);
    int DllExport initialize();
    int DllExport setOption(const char* key, const char *value);
    int DllExport getOption(const char* key, char *value, unsigned int* size);
    int DllExport getVersion(char *value, unsigned int* size);
    int DllExport getRuleVersion(int ruleFileIndex,char *versionBuffer);
    int DllExport verifyRuleFileFormat(char *filepath, int* valid);
    int DllExport getLastRuleUpdateTime(time_t *updateTime);
    int DllExport setRuleUpdateCallback(void (*callbackFunction)(void *),void *opaque);
    int DllExport setRetrieveRuleProgressCallback(retrieve_progress_callback func,void *opaque);

    int DllExport computeScore(const char* buf, unsigned int len, unsigned int* score);
    int DllExport reloadOptions();
    int DllExport reloadRules(const char* rules_dir);
    int DllExport retrieveRules(const char* rules_dir);

    int DllExport addAddress(int offset_score, const char * address);
    int DllExport addMessage(int offset_score, const char * message,
      unsigned int msg_size, int signedsender);
    int DllExport deleteAddress(const char * address);
    int DllExport deleteMessage(const char * message, unsigned int msg_size);
    int DllExport saveScoreOffsets();
    int DllExport flushTrainingWriteBuffer();
    int DllExport getReputeIP(const char* ip, unsigned int* score);
    int DllExport getReputeDomain(const char* domain, unsigned int* score);
    int DllExport retrieveEngineUpdate();
    int DllExport reloadEngineUpdate();

    DllExport ~Mailshell();

  private:
    void *e;
};

class MailshellMsg
{
  public:
    DllExport MailshellMsg(Mailshell *mailshell);
    int DllExport setSmtpIPaddr(const char *value);
    int DllExport setSmtpEnvelope(const char *value);
    int DllExport greylistCheck();
    int DllExport computeScore(const char* buf, unsigned int len, unsigned int* score);
    int DllExport computeScore(const char *headers, const char* buf, unsigned int len, unsigned int* score);
    int DllExport newsletterCheck(const char* buf, unsigned int len, int* id);
    int DllExport getExtraInfo(const char* key, char *value, unsigned int* size);
    int DllExport setOption(const char* key, const char *value);
    int DllExport getOption(const char* key, char *value, unsigned int* size);
    int DllExport dkimSign(const char*buf, unsigned int msg_len, const char *secretkey,
      const char *selector, const char *domin, unsigned int hdr_canon_alg,
      unsigned int body_canon_alg, unsigned int sign_alg, int sign_len,
      char * ret_header, int *ret_header_size) ;
    DllExport ~MailshellMsg();

  private:
    void *m;
};
#endif

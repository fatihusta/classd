#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/socket.h>
#include <string.h>
#include <mailshellc.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <signal.h>
#include <netinet/in.h>
#include <sysexits.h>
#include <ctype.h>
#include <arpa/inet.h>

#define TMPBUFSIZE 4096 
#define SPAMTAGBUFSIZE 5120 
#define REPLYHEADERSIZE 1024
#define SPAMCATD "SPAMD/1.5"
#define PONG 10 
#define CHUNKSIZE 4096 
#define SOCKREADTIMEOUT 10 

int sock;
void *engine; 
unsigned int MSG_BUFSIZE=1048576;
volatile sig_atomic_t stop=0;

struct options
{
  int port;
  char ip[16];
  char conf_dir[1000];
  int spam_threshold;
};
struct options spamd_options={783,"0.0.0.0","./conf",90};

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

enum commands
{
  INVALID_COMMAND=0,
  CHECK,
  SYMBOLS,
  REPORT,
  REPORT_IFSPAM,
  SKIP,
  PING,
  HEADERS,
  PROCESS
};

// A link-list node of char *buffers
typedef struct buf_node {
  const char *buf;
  size_t len;
  struct buf_node *next;
} buf_node;

void buf_node_init(buf_node *n) {
  n->buf=NULL;
  n->len=0;
  n->next=NULL;
}

void buf_node_free(buf_node *n) {
  if (!n) return;
  // Do not free 'buf' since that is externally allocated
  if (n->buf) n->buf = NULL;
  n->len=0;
  if (n->next) {
    buf_node_free(n->next);
    free(n->next);
  }
}

void buf_node_append(buf_node *n, const char *str, int len) {
  if (!n) return;

  // Traverse to end of list
  buf_node *tmp=n;
  for (tmp = n; tmp->next != NULL; tmp = tmp->next) ;

  if (tmp->buf != NULL) {
    // Need a new node
    tmp->next = (buf_node *)malloc(sizeof(buf_node));
    if (!tmp->next) return; // Error
    tmp = tmp->next;
  }
  tmp->buf = str;
  tmp->len = len;
  tmp->next = NULL;
}

void trimwhitespace(char *str)
{
  const char *start=str;
  const char *end=str+strlen(str);
  // move past the leading whitespace
  while(isspace(*start)) start++;
  if (*str == 0) return;
  // move past the trailing whitespace
  while (end >= str && (isspace(*end) || *end==0)) end--;
  if (end-start > 0)
  {
    memmove(str, start, end-start+1);
    str[end-start+1]='\0';
  }
}

void get_status_message(int statCode, char *statMsg)
{
  switch(statCode)
  {
    case EX_OK:
      sprintf(statMsg,"%s %d %s\r\n",SPAMCATD,statCode,"EX_OK");
      break;
    case PONG:
      sprintf(statMsg,"%s 0 %s\r\n",SPAMCATD,"PONG");
      break;
    case EX_NOINPUT:
      sprintf(statMsg,"%s %d %s\r\n",SPAMCATD,statCode,"EX_NOINPUT");
      break;
    case EX_PROTOCOL:
      sprintf(statMsg,"%s %d %s\r\n",SPAMCATD,statCode,"EX_PROTOCOL");
      break;
    default:
      sprintf(statMsg,"%s %d %s\r\n",SPAMCATD,statCode,"EX_SOFTWARE");
      break;
  }
}

int init_mailshell(char *conf_dir)
{
  char *buf=NULL;
  int buflen=0;
  int rc=MAILSHELL_INVALID_CONFIG_DIR;
  engine = Mailshell_constructor(conf_dir);
  if(engine) 
  {
    rc = Mailshell_retrieveRules(engine,conf_dir);
    if (rc==MAILSHELL_OK) 
      fprintf(stdout,"Done updating rules, rc is %d\n",rc);
    else if (rc==MAILSHELL_RULES_UPTODATE)
      fprintf(stdout,"Rules already up-to-date, rc is %d\n",rc);
    else
      fprintf(stdout,"Error updating rules, rc is %d\n",rc);
    rc=Mailshell_initialize(engine);
    switch(rc) 
    {
      case MAILSHELL_OK:
        fprintf(stdout,"Engine Init ok.\n");
        break;
      case MAILSHELL_LICENSE_INVALID:
        fprintf(stdout,"ERROR: Mailshell License is invalid.\n");
        free(engine);
        engine=NULL;
        break;
      case MAILSHELL_LICENSE_EXPIRED:
        fprintf(stdout,"ERROR: Mailshell License is expired.\n");
        free(engine);
        engine=NULL;
        break;
      case MAILSHELL_INVALID_CONFIG_DIR:
        fprintf(stdout,"ERROR: Invalid Configuration Directory.\n");
        free(engine);
        engine=NULL;
        break;
      case MAILSHELL_NO_RULES_LOADED:
        fprintf(stdout,"ERROR: No Rules Loaded.\n");
        free(engine);
        engine=NULL;
        break;
      default: 
        fprintf(stdout,"ERROR: Unknown Error occured.\n");
        free(engine);
        engine=NULL;
        break;
    }
  }
  return rc;
} 

int score_message(const char *buf, int bufLen, unsigned int *score, const char *info, char *scoring_info, unsigned int scoring_info_size)
{
  void *msg;
  int i;
  int rc=0;
  
  if (scoring_info && scoring_info_size > 0) scoring_info[0]=0;
  msg = MailshellMsg_constructor(engine);
  if (msg) 
  {
    rc = MailshellMsg_computeScore(msg,buf,bufLen,score);
    if (rc != MAILSHELL_OK) rc = EX_SOFTWARE;
    if (rc == MAILSHELL_OK && info && scoring_info)
    {
      unsigned int tmp = scoring_info_size;
      rc = MailshellMsg_getExtraInfo(msg, info, scoring_info, &tmp);
      if (rc != MAILSHELL_OK) rc = EX_SOFTWARE;
      else {
        if (!(scoring_info[tmp-1]=='\r' && scoring_info[tmp] == '\n')) {
          scoring_info[tmp-1]='\r';
          scoring_info[tmp]='\n';
        }
      }
    }
    MailshellMsg_destructor(msg);
  }
  return rc;
}

// cleanup() is called to kill the thread upon SIGINT. 
void cleanup(int signal)
{
    stop=1;
    close(sock);
    //pthread_exit(NULL);
    return;
} /* cleanup() */

int process_command(int command, char *message, int total_len, int sock)
{
  unsigned int score=0,rc=0;
  const char *spam_status=NULL;
  const char *scoring_attr=NULL;
  char scoring_info[TMPBUFSIZE];
  char reply[TMPBUFSIZE];
  char reply_header[REPLYHEADERSIZE];
  char spam_tags[SPAMTAGBUFSIZE];
  char cl_buf[TMPBUFSIZE];
  buf_node reply_node_bufs;
  
  buf_node_init(&reply_node_bufs);
  
  switch(command)
  {
    case INVALID_COMMAND: 
      get_status_message(EX_PROTOCOL,reply_header);
      buf_node_append(&reply_node_bufs, reply_header, strlen(reply_header));
      break;

    case SKIP:
      //printf("SKIP\n");
      break;

    case PING:
      get_status_message(PONG,reply_header);
      buf_node_append(&reply_node_bufs, reply_header, strlen(reply_header));
      break;

    case CHECK:
    case SYMBOLS:
      // CHECK is identical to SYMBOLS except that SYMBOLS also returns those symbols which hit
    case REPORT:
    case REPORT_IFSPAM:
      // REPORT_IFSPAM is identical to REPORT except that REPORT_IFSPAM only replies if message is spam
      scoring_attr = (command == SYMBOLS) ? "scoring_explanation" : "scoring_summary";
      rc = score_message(message, total_len, &score,scoring_attr, scoring_info, TMPBUFSIZE);
      spam_status = (score < spamd_options.spam_threshold) ? "False" : "True";
      get_status_message(rc, reply_header);
      if (!(command == REPORT_IFSPAM && score < spamd_options.spam_threshold))
      {
        buf_node_append(&reply_node_bufs, reply_header, strlen(reply_header));
        if (command != CHECK) {
          snprintf(cl_buf, sizeof(cl_buf), "Content-length: %d\r\n",strlen(scoring_info));
          buf_node_append(&reply_node_bufs, cl_buf, strlen(cl_buf));
        }
        snprintf(reply, sizeof(reply), "Spam: %s ; %d / %d\r\n\r\n",
                 spam_status,score,spamd_options.spam_threshold);
        buf_node_append(&reply_node_bufs, reply, strlen(reply));
        if (command != CHECK) {
          buf_node_append(&reply_node_bufs, scoring_info, strlen(scoring_info));
        }
      }
      break;

    case HEADERS:
    case PROCESS:
      // PROCESS is identical to HEADERS except for echoing back to full message vs headers only
      rc = score_message(message,total_len,&score,"scoring_summary",scoring_info,TMPBUFSIZE);
      spam_status = (score < spamd_options.spam_threshold) ? "False" : "True";
      get_status_message(rc,reply_header);
      buf_node_append(&reply_node_bufs, reply_header, strlen(reply_header));

      size_t msg_bytes;
      if (command == HEADERS) {
        msg_bytes = 0;
        // Find the  Header-body separator CR-LF-CR-LF
        char *eoh = strstr(message,"\r\n\r\n");
        if (eoh) msg_bytes = eoh + 4 - message;
      } else if (command == PROCESS) {
        msg_bytes = total_len;
      } else {
        msg_bytes = 0;
      }
      spam_tags[0]=0;
      snprintf(spam_tags, sizeof(spam_tags),
               "X-Spam-Status:%s\r\nX-Spam-Score:%d\r\nX-Spamcatcher-Summary:%s",
               spam_status, score, scoring_info);
      spam_tags[sizeof(spam_tags)-1]=0;
      snprintf(reply, sizeof(reply),
               "Content-length: %d\r\nSpam: %s ; %d / %d\r\n\r\n",
               msg_bytes + strlen(spam_tags),
               spam_status, score, spamd_options.spam_threshold);
      
      buf_node_append(&reply_node_bufs, reply, strlen(reply));
      buf_node_append(&reply_node_bufs, spam_tags, strlen(spam_tags));
      buf_node_append(&reply_node_bufs, message, msg_bytes);
      break;

    default:
      break;
  }

  // Write out all the buffer nodes
  buf_node *tmp;
  for (tmp = &reply_node_bufs; tmp; tmp = tmp->next) {
    if (tmp->buf && tmp->len > 0) {
      int bytesWritten = send(sock, tmp->buf, tmp->len, MSG_NOSIGNAL);
      if (bytesWritten < 0) error("ERROR writing to socket");
    }
  }
  buf_node_free(&reply_node_bufs);
}

int status_code(const char *status)
{
  if (!strcmp(status,"CHECK"))
    return CHECK;
  else if (!strcmp(status,"SYMBOLS"))
    return SYMBOLS;
  else if (!strcmp(status,"REPORT"))
    return REPORT;
  else if (!strcmp(status,"REPORT_IFSPAM"))
    return REPORT_IFSPAM;
  else if (!strcmp(status,"SKIP"))
    return SKIP;
  else if (!strcmp(status,"PING"))
    return PING;
  else if (!strcmp(status,"HEADERS"))
    return HEADERS;
  else if (!strcmp(status,"PROCESS"))
    return PROCESS;
  else
    return INVALID_COMMAND;
}

void upper_str(char *s)
{
  char  *p;

  for (p = s; *p != '\0'; p++) 
    *p = (char) toupper(*p);
}
    
void *process(void *ptr)
{
  int len,n;
  long addr = 0;
  char *full_buffer=NULL;
  char *tmp=NULL;
  int content_length=0;
  char buffer[CHUNKSIZE];
  int i;
  int bytes_read=0;
  char *request=NULL;
  size_t request_len=0;
  size_t request_size=0;
  char command[100];
  int ver_major=0;
  int ver_minor=0;
  int command_code=0;
  struct timeval tv;
  int sock=-1;
  size_t eoc_index=0; //End-of-command line
  size_t eoh_index=0; //End-of-headers

  sock = *((int*) (&ptr));
  if (sock<=0) pthread_exit(0); 
  command[0]=0;

  tv.tv_sec = SOCKREADTIMEOUT;  
  tv.tv_usec = 0;  
  setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv,sizeof(struct timeval));

  // Spamd requests have the following formart
  // COMMAND SPAMC/X.Y\r\n     <-- Command and Version number, End-of-command
  // User: XX\r\n              
  // Content-Length: XX\r\n
  // .....
  // HeaderN: ValueN\r\n
  // \r\n                      <-- End-of-headers (eoh_index), also beginning of message
  // Message...                <-- End of message is eoh_index + Content-Length header

  while((bytes_read=recv(sock,buffer,sizeof(buffer), MSG_NOSIGNAL))>0 && 
        (bytes_read+request_len) < MSG_BUFSIZE)
  {  
     // There's no guarantee that network bytes will arrive aligned to CRLF,
     // so need to chunk together the request 
     if (request_size <= request_len + bytes_read) {
       request = (char *)realloc(request, (request_len + bytes_read) * 2);
       request_size = (request_len + bytes_read) * 2;
     }
     memcpy(request+request_len, buffer, bytes_read);
     request_len += bytes_read;
     request[request_len]=0;

     // Find beginning-of-headers
     if (!eoc_index) {
       char *crlf = strstr(request, "\r\n");
       if (crlf) {
         eoc_index = crlf - request;
         int n = sscanf(request, "%99[^ \r\n] SPAMC/%d.%d", command, &ver_major, &ver_minor);
         if (n != 3) {
           strncpy(command, "INVALID_COMMAND", sizeof(command));
           break;
         }
         upper_str(command);
       }
     }
     
     // Find end-of-headers
     if (eoc_index && !eoh_index) {
       char *crlf = strstr(request+eoc_index, "\r\n\r\n");
       if (crlf) {
         crlf += sizeof("\r\n\r\n") - 1;
         eoh_index = crlf - request;
         //Start looking for CONTENT-LENGTH:
         char *p = request + eoc_index;
         while (p && p < crlf) {
           //Copy the first sizeof("CONTENT-LENGTH:") bytes
           char *end = strstr(p, "\r\n");
           if (end-p > sizeof("CONTENT-LENGTH:")) {
             char *cl_buf = (char *)malloc(end-p + 1);
             if (cl_buf) {
               memcpy(cl_buf,p,end-p);
               cl_buf[end-p]=0;
               upper_str(cl_buf);
               if (!strncmp("CONTENT-LENGTH:", cl_buf, sizeof("CONTENT-LENGTH:")-1)) {
                 content_length = atoi(cl_buf + sizeof("CONTENT-LENGTH:"));
               }
               free(cl_buf);
               if (content_length != 0) break;
             }
           }
           // Move on to next line
           if (p) p = end + sizeof("\r\n") - 1;
         }
       }
     }
     
     // We have received enough bytes when
     // For PING or SKIP versions < 1.5: Just first line
     // For PING or SKIP versions >= 1.5: End-of-headers marker
     // For other commands: At least content_length bytes 
     // Beginning with version 1.5, SKIP and PING require CRLF
     // Otherwise we need need to wait for Content-Length bytes
     if ((!strcmp(command,"PING") || !strcmp(command,"SKIP")) &&
         ((ver_major <= 1 && ver_minor < 5) || eoh_index>0)) break;
     if (eoh_index>0 && int((request_len - eoh_index) >= content_length)) break;
  }
  
  command_code=status_code(command);
  process_command(command_code, request+eoh_index, content_length, sock);

  if (request) free(request);
  close(sock);
  pthread_exit(NULL);
}

void * read_options_file(char *fname)
{
  FILE *fp=NULL;
  size_t nbytes;
  char *line=NULL;
  unsigned int bytes_read=0;
  char *key=NULL;
  char *value=NULL;

  fp=fopen(fname, "r" );
  if(fp == 0 )
  {
    printf( "Could not open spamd conf file\n" );
  }
  else
  {
    while ((bytes_read = getline(&line, &nbytes, fp)) != -1)
    {
      trimwhitespace(line);
      char *pch=strchr(line,'=');
      if(pch !=NULL && line[0]!='#')
      {
        key = line;
        *pch = 0; // Replace = with NUL
        value = pch + 1;
        trimwhitespace(key);
        trimwhitespace(value);
        if (!strcmp(key,"port"))
          spamd_options.port=atoi(value);
        else if(!strcmp(key,"ip"))
          strncpy(spamd_options.ip, value, sizeof(spamd_options.ip));
        else if (!strcmp(key,"conf_dir"))
          strncpy(spamd_options.conf_dir, value, sizeof(spamd_options.conf_dir));
        else if (!strcmp(key,"spam_threshold"))
          spamd_options.spam_threshold=atoi(value);
      }
    }
    if (line) free(line);
    fclose(fp);
  }
}

int main(int argc, char ** argv)
{
  int new_sock = -1;
  struct sockaddr_in address;
  int port;
  pthread_t thread; /* thread variable */
  int rc=0;
  struct sigaction action;
  memset(&action, 0, sizeof(struct sigaction));
  action.sa_handler = cleanup;
  sigaction(SIGTERM, &action, NULL);
  // signal(SIGTERM, cleanup);

  /* check for command line arguments */
  if (argc == 2)
  {
    read_options_file(argv[1]);
  }
  rc = init_mailshell(spamd_options.conf_dir);
  if(rc != MAILSHELL_OK)
  {
    fprintf(stdout,"Error initializing Mailshell Antispam Engine...Aborting\n");
    return -1;
  }
  fprintf(stdout,"Maishell Engine sucessfully started\n");

  /* create socket */
  sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (sock <= 0)
  {
    fprintf(stderr, "%s: error: cannot create socket\n", argv[0]);
    return -3;
  }

  /* bind socket to port */
  address.sin_family = AF_INET;
  address.sin_addr.s_addr = inet_addr(spamd_options.ip);
  address.sin_port = htons(spamd_options.port);
  int so_reuseaddr = 1;
  setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &so_reuseaddr, sizeof(so_reuseaddr));

  if (bind(sock, (struct sockaddr *)&address, sizeof(address)) < 0)
  {
    fprintf(stderr, "%s: error: cannot bind socket to port %d\n", argv[0], spamd_options.port );
    return -4;
  }

  /* listen on port */
  if (listen(sock, 5) < 0)
  {
    fprintf(stderr, "%s: error: cannot listen on port\n", argv[0]);
    return -5;
  }

  printf("%s: ready and listening\n", argv[0]);
	
  pthread_attr_t pta;
  pthread_attr_init(&pta);
  while (!stop)
  {
    /* accept incoming connections */
    new_sock = accept(sock,(struct sockaddr*)NULL, NULL);
    if (new_sock > 0)
    {
      /* start a new thread */
      pthread_create(&thread, &pta, process, (void *) new_sock);
      pthread_detach(thread);
    }
  }
  if (sock) close(sock);
  if (engine) Mailshell_destructor(engine);
  return 0;
}


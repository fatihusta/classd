#ifndef MAILSHELLC_H
#define MAILSHELLC_H
/* This is a C interface to the Mailshell SpamCatcher SDK. */
#include <time.h>

#if (defined _cplusplus || defined __cplusplus)
extern "C"
{
#endif

#ifndef MAILSHELL_OK
#   define MAILSHELL_OK 0
#endif

#ifndef MAILSHELL_INVALID_ARG
#   define MAILSHELL_INVALID_ARG 1001
#endif

#ifndef MAILSHELL_INVALID_OPTION_KEY
#   define MAILSHELL_INVALID_OPTION_KEY 1002
#endif

#ifndef MAILSHELL_INVALID_OPTION_VALUE
#   define MAILSHELL_INVALID_OPTION_VALUE 1003
#endif

#ifndef MAILSHELL_BUFFER_TOO_SMALL
#   define MAILSHELL_BUFFER_TOO_SMALL 1004
#endif

#ifndef MAILSHELL_NO_MEMORY
#   define MAILSHELL_NO_MEMORY 1005
#endif

#ifndef MAILSHELL_LICENSE_INVALID
#   define MAILSHELL_LICENSE_INVALID 1006
#endif

#ifndef MAILSHELL_LICENSE_EXPIRED
#   define MAILSHELL_LICENSE_EXPIRED 1007
#endif

#ifndef MAILSHELL_INVALID_CONFIG_DIR
#   define MAILSHELL_INVALID_CONFIG_DIR 1008
#endif

#ifndef MAILSHELL_NO_RULES_LOADED
#   define MAILSHELL_NO_RULES_LOADED 1009
#endif

#ifndef MAILSHELL_LICENSE_OVERUSED
#   define MAILSHELL_LICENSE_OVERUSED 10010
#endif

#ifndef MAILSHELL_RULES_NOT_RETRIEVED
#   define MAILSHELL_RULES_NOT_RETRIEVED 10011
#endif

#ifndef MAILSHELL_NETWORK_ERROR
#   define MAILSHELL_NETWORK_ERROR 10016
#endif

#ifndef MAILSHELL_MERGE_FAILED
#   define MAILSHELL_MERGE_FAILED 10017
#endif

#ifndef MAILSHELL_RULES_UPTODATE
#   define MAILSHELL_RULES_UPTODATE 10018
#endif

#ifndef MAILSHELL_ENGINE_UPTODATE
#   define MAILSHELL_ENGINE_UPTODATE 10019
#endif

#ifndef MAILSHELL_INVALID_DLL
#   define MAILSHELL_INVALID_DLL 10020
#endif

#ifndef TMP_FAIL
#   define TMP_FAIL 0
#endif

#ifndef TMP_SUCCESS
#   define TMP_SUCCESS 1
#endif

#ifndef GREYLIST_TMPFAIL
#   define GREYLIST_TMPFAIL 0
#endif

#ifndef GREYLIST_PASS
#   define GREYLIST_PASS 1
#endif

#ifndef GREYLIST_FULL
#   define GREYLIST_FULL 3
#endif

#ifndef MAILSHELL_DKIM_OK
#   define MAILSHELL_DKIM_OK 0
#endif

#ifndef MAILSHELL_DKIM_SIGNFAIL
#   define MAILSHELL_DKIM_SIGNFAIL 1
#endif

#ifndef MAILSHELL_DKIM_BAD_PARAM
#   define MAILSHELL_DKIM_BAD_PARAM 2
#endif

#ifndef MAILSHELL_DKIM_INVALID
#   define MAILSHELL_DKIM_INVALID 3
#endif

#ifndef MAILSHELL_DKIM_CANON_SIMPLE
#   define MAILSHELL_DKIM_CANON_SIMPLE 0
#endif

#ifndef MAILSHELL_DKIM_CANON_RELAXED
#   define MAILSHELL_DKIM_CANON_RELAXED 1
#endif

#ifndef MAILSHELL_DKIM_SIGN_RSASHA1
#   define MAILSHELL_DKIM_SIGN_RSASHA1 0
#endif

#ifndef MAILSHELL_DKIM_SIGN_RSASHA256
#   define MAILSHELL_DKIM_SIGN_RSASHA256 1
#endif

#ifndef MAILSHELLAPI
#   ifdef WIN32
#      define MAILSHELLAPI _stdcall
#   else
#      define MAILSHELLAPI
#   endif
#endif

#ifndef retrieve_progress_callback
  typedef int (*retrieve_progress_callback)(void *opaque,int ruleFileIndex, int dltotal,int dlnow,int ultotal,int ulnow);
#endif

  /* get a reference to the Mailshell Spam engine */
  void * MAILSHELLAPI Mailshell_constructor(const char *confdir);
  typedef void* (MAILSHELLAPI *Mailshell_constructorProc)(const char *);

  /* release memory associated with Mailshell Spam engine */
  int MAILSHELLAPI Mailshell_destructor(void *pEngine);
  typedef int (MAILSHELLAPI *Mailshell_destructorProc)(void *);

  /* initialize the Mailshell Spam engine */
  int MAILSHELLAPI Mailshell_initialize(void *pEngine);
  typedef int (MAILSHELLAPI *Mailshell_initializeProc)(void *);

  /* determine the score for a message */
  int MAILSHELLAPI Mailshell_computeScore(void *pEngine, const char* buf, unsigned int len, unsigned int* score);
  typedef int (MAILSHELLAPI *Mailshell_computeScoreProc) (void *, const char *, unsigned int, unsigned int*);

  /* set a Mailshell Spam Engine option */
  int MAILSHELLAPI Mailshell_setOption(void *pEngine, const char *key, const char *value);
  typedef int (MAILSHELLAPI *Mailshell_setOptionProc)(void *, const char *, const char*);

  /* get a Mailshell Spam Engine option */
  int MAILSHELLAPI Mailshell_getOption(void *pEngine, const char *key, char *value, unsigned int* size);
  typedef int (MAILSHELLAPI *Mailshell_getOptionProc)(void *, const char *, char*, unsigned int*);

  /* get the version of the Spam Engine */
  int MAILSHELLAPI Mailshell_getVersion(void *pEngine, char *value, unsigned int* size);
  typedef int (MAILSHELLAPI *Mailshell_getVersionProc)(void *, char *, unsigned int*);

  /* Instruct Spam Engine to activate previous setOption() calls */
  int MAILSHELLAPI Mailshell_reloadOptions(void *pEngine);
  typedef int (MAILSHELLAPI *Mailshell_reloadOptionsProc)(void *);

  /* force Spam Engine to reload rules from specified directory */
  int MAILSHELLAPI Mailshell_reloadRules(void *pEngine, const char *rules_dir);
  typedef int (MAILSHELLAPI *Mailshell_reloadRulesProc)(void *, const char *);

  /* force Spam Engine to retrieve rules from the SpamCatcher network into the specified directory */
  int MAILSHELLAPI Mailshell_retrieveRules(void *pEngine, const char *rules_dir);
  typedef int (MAILSHELLAPI* Mailshell_retrieveRulesProc) (void *, const char *);

  /* set scoring offsets for messages or addresses */
  int MAILSHELLAPI Mailshell_addAddress(void *pEngine, int offset_score,
    const char * address);
  typedef int (MAILSHELLAPI* Mailshell_addAddressProc)(void *, int, const char *);

  /* set scoring offsets for messages or addresses */
  int MAILSHELLAPI Mailshell_addMessage(void *pEngine, int offset_score,
    const char * message, unsigned int msg_size,
    int signedsender);
  typedef int (MAILSHELLAPI* Mailshell_addMessageProc)(void *, int,
    const char *, unsigned int, int);

  /* remove message or address from offset computations */
  int MAILSHELLAPI Mailshell_deleteAddress(void * pEngine, const char * address);
  typedef int (MAILSHELLAPI* Mailshell_deleteAddressProc)(void *, const char *);

  int MAILSHELLAPI Mailshell_deleteMessage(void * pEngine,
    const char * message, unsigned int msg_size);
  typedef int (MAILSHELLAPI* Mailshell_deleteMessageProc)(void *, const char *, unsigned int);

  int MAILSHELLAPI Mailshell_saveScoreOffsets(void *);
  typedef int (MAILSHELLAPI* Mailshell_saveScoreOffsetsProc)(void *);

  int MAILSHELLAPI Mailshell_flushTrainingWriteBuffer(void *);
  typedef int (MAILSHELLAPI* Mailshell_flushTrainingWriteBufferProc)(void *);

  /* get reputation score for IP */
  int MAILSHELLAPI Mailshell_getReputeIP(void *pEngine, const char* ip, unsigned int* score);
  typedef int (MAILSHELLAPI *Mailshell_getReputeIPProc)(void *,const char* ip, unsigned int* score);

  /* get reputation score for Domain */
  int MAILSHELLAPI Mailshell_getReputeDomain(void *pEngine, const char* domain, unsigned int* score);
  typedef int (MAILSHELLAPI *Mailshell_getReputeDomainProc)(void *,const char* ip, unsigned int* score);

  int MAILSHELLAPI Mailshell_getRuleVersion(void *pEngine, int ruleFileIndex,
    char *versionBuffer);
  typedef int (MAILSHELLAPI *Mailshell_getRuleVersionProc)(void *, int, char *);

  int MAILSHELLAPI Mailshell_verifyRuleFileFormat(void *pEngine, char *filepath, int* valid);
  typedef int (MAILSHELLAPI *Mailshell_verifyRuleFileFormatProc)(void *, char *, int *);

  int MAILSHELLAPI Mailshell_getLastRuleUpdateTime(void *pEngine, time_t *updateTime);
  typedef int (MAILSHELLAPI *Mailshell_getLastRuleUpdateTimeProc)(void *,time_t *);

  int MAILSHELLAPI Mailshell_setRuleUpdateCallback(void *pEngine,
    void (*callbackFunction)(void *),void *opaque);
  typedef int (MAILSHELLAPI *Mailshell_setRuleUpdateCallbackProc)(void *, void (*callbackFunction)(void *),void *);

  int MAILSHELLAPI Mailshell_setRetrieveRuleProgressCallback(void *pEngine,
    retrieve_progress_callback func,void *opaque);
  typedef int (MAILSHELLAPI *Mailshell_setRetrieveRuleProgressCallbackProc)(void *, retrieve_progress_callback,void *);

  int MAILSHELLAPI Mailshell_retrieveEngineUpdate(void *);
  typedef int (MAILSHELLAPI* Mailshell_retrieveEngineUpdateProc)(void *);

  int MAILSHELLAPI Mailshell_reloadEngineUpdate(void *);
  typedef int (MAILSHELLAPI* Mailshell_reloadEngineUpdateProc)(void *);

  /* get a reference to MailshellMsg */
  void * MAILSHELLAPI MailshellMsg_constructor(void *pEngine);
  typedef void * (MAILSHELLAPI *MailshellMsg_constructorProc)(void *);

  /* release memory associated with MailshellMsg */
  int MAILSHELLAPI MailshellMsg_destructor(void *pMessage);
  typedef int (MAILSHELLAPI *MailshellMsg_destructorProc) (void *);

  /* set the SMTP IP address which generated the message */
  int MAILSHELLAPI MailshellMsg_setSmtpIPaddr(void *pMessage, const char *value);
  typedef int (MAILSHELLAPI *MailshellMsg_setSmtpIPaddrProc)(void *, const char *);

  /* set the SMTP envelope which generated the message */
  int MAILSHELLAPI MailshellMsg_setSmtpEnvelope(void *pMessage, const char *value);
  typedef int (MAILSHELLAPI *MailshellMsg_setSmtpEnvelopeProc)(void *, const char *);

  /* determine the score for a message */
  int MAILSHELLAPI MailshellMsg_computeScore(void *pMessage, const char* buf, unsigned int len, unsigned int* score);
  typedef int (MAILSHELLAPI *MailshellMsg_computeScoreProc) (void *, const char *, unsigned int, unsigned int*);

  int MAILSHELLAPI MailshellMsg_dkimSign(void *pMessage, const char *buf, unsigned int msg_len, const char *secretkey,
    const char *selector, const char *domin, unsigned int hdr_canon_alg,
    unsigned int body_canon_alg, unsigned int sign_alg, int sign_len,
    char *ret_header, int *ret_header_size) ;
  typedef int (MAILSHELLAPI *MailshellMsg_dkimSignProc)(void *, const char *, unsigned int, const char *,
    const char *, const char *, unsigned int, unsigned int, unsigned int, int, char *, int *) ;

  /* set the SMTP IP address which generated the message */
  int MAILSHELLAPI MailshellMsg_greylistCheck(void *pMessage);
  typedef int (MAILSHELLAPI *MailshellMsg_greylistCheckProc)(void *);

  /* determine whether message appears to be newsletter */
  int MAILSHELLAPI MailshellMsg_newsletterCheck(void *pMessage, const char* buf, unsigned int len, int* id);
  typedef int (MAILSHELLAPI *MailshellMsg_newsletterCheckProc) (void *, const char *, unsigned int, int*);

  /* get additional information regarding the scoring */
  int MAILSHELLAPI MailshellMsg_getExtraInfo(void *pMessage, const char *key, char *value, unsigned int* size);
  typedef int (MAILSHELLAPI *MailshellMsg_getExtraInfoProc)(void *, const char *, char*, unsigned int*);

  /* set a Mailshell Spam Engine option */
  int MAILSHELLAPI MailshellMsg_setOption(void *pEngine, const char *key, const char *value);
  typedef int (MAILSHELLAPI *MailshellMsg_setOptionProc)(void *, const char *, const char*);

  /* get a Mailshell Spam Engine option */
  int MAILSHELLAPI MailshellMsg_getOption(void *pEngine, const char *key, char *value, unsigned int* size);
  typedef int (MAILSHELLAPI *MailshellMsg_getOptionProc)(void *, const char *, char*, unsigned int*);

#if (defined _cplusplus || defined __cplusplus)
}                                /* extern "C" */
#endif
#endif

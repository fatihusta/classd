///////////////////////////////////////////////////////////////////////////////
// This application analyzes a single mail message and outputs a score for it.
// Syntax: example -D <configdir> <message>
// Arguments:  
//  configdir - required. Directory containing rules and spamcatcher.conf
//  message - name of file to analyze
///////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <mailshell.h>
#include <string>

using namespace std;
const int MAX_MSG_SIZE=20000;

void usage() {
	cout << "Syntax: example -D <confdir>  <msg>" << endl;
	exit(0);
}

int main (int argc, char **argv)
{
	string SpamCatcherDir;
	string messageFile;

	// Parse command line options
	//
	for (int i=1; i < argc; i++) {
		string arg = argv[i];
		if (arg=="-D") {
			i++;
			if (i>=argc) usage();
				SpamCatcherDir = argv[i];
		} 
		else {
			messageFile = argv[i];
		}
	}


	if (SpamCatcherDir.empty() || messageFile.empty()) {
		usage();
	}
	
	// Instantiate a new Mailshell object
	Mailshell* engine = new Mailshell(SpamCatcherDir.c_str());
	
	char vbuf[40];
	unsigned int vbufSize = 40;

	// determine Mailshell SDK version
	engine->getVersion(vbuf, &vbufSize);

	cout << "SDK version: " << vbuf << endl;

	// Refresh rules every 600 seconds (10 minutes);
	engine->setOption("ruleupdate","600");
	
	// Don�t do network checks
	engine->setOption("netcheck","no");
	
	int result = engine->initialize();
	
	if (result!=MAILSHELL_OK) {
		cerr << "initialize failed with return code: "  << result <<endl;
		exit(1);
	}

	//Buffer to hold contents of message
	char buf[MAX_MSG_SIZE];
	FILE *fp = fopen(messageFile.c_str(),"r");
	if (!fp) {
		cerr << "could not open file:  "<< messageFile << endl;
		exit(1);
	}

	// Read contents of message file into buffer
	int buf_len=0;
	while (!feof(fp) && (buf_len < MAX_MSG_SIZE) ) {
		int chunk = MAX_MSG_SIZE - buf_len;
		buf_len += fread(buf+buf_len,1,chunk,fp);
	}
	fclose(fp);
	
	// Create a new Mailshell Object for this message
	MailshellMsg* msg = new MailshellMsg(engine);
	unsigned int score=0;
	
	// Get a score
	result = msg->computeScore(buf,buf_len,&score);
	if (result==MAILSHELL_OK) {
		cout << "score is: " << score <<endl;
	} else {
		cout << "computeScore failed with return code: "<<
		result <<endl;
	}
	
	// Now that we are done scoring we should destroy
	// the MailshellMsg object
	if (msg) delete msg;
	
	
	if (engine) delete engine;

	exit(0);
	return 0;
}

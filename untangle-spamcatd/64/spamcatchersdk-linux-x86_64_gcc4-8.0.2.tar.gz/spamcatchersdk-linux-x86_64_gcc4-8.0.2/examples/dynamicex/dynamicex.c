///////////////////////////////////////////////////////////////////////////////
// This example application uses multiple threads to analyze a directory of
// messages. The output will be a score for each message, along with 
// a summary of the results.
// This example uses the Mailshell C interface
// Syntax: dynamicex -D <configdir> -t <numthreads> -l <loops> -v -m <progress> -regkey <regkey>
//			-netcheck <setting> -use_cache <setting> -verbose <setting> 
//			-ruleupdate <setting> -sntimeout <setting> <directory>
//
// Arguments:  
//  configdir - Required. Directory containing rules and spamcatcher.conf
//  directory - Required. Directory containing mail messages to analyze.
//  numthreads - Optional. Number of threads to use. Defaults to 1.
//  loops - Optional. Number of times to loop through messages. Defaults to 1.
//  progress - Optional. Number of messages after which total number of processed messages. 
//		Defaults to 10 thus far is shown.
//  v  - Optional. Flag to output score for each message. Defaults to off.
//  regkey - Optional. registration key
//  netcheck setting - Optional. Either yes or no. Defaults to no.
//  use_cache setting - Optional. Either yes or no. Applies if netcheck=no. 
//		Defaults to yes.
//  verbose setting - Optional.  Either yes or no. Defaults to no.
//  ruleupdate setting - Optional.  Indicates number of seconds between checks.
//		Defaults to 3600.
//  sntimeout setting - Optional. Indicates number of seconds to time out when
//		connecting to SpamCatcher Network. Defaults to 5.
// Example:  dynamicex -D conf messagedir
///////////////////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef WIN32
#include <io.h>
#include <process.h>
#include <windows.h>
#else
#include <dirent.h>
#include <unistd.h>
#include <sys/time.h>
#include <pthread.h>
#include <semaphore.h>
#include <dlfcn.h>
#include <link.h>
#endif

#include <stdio.h>
#include <string.h>

#include <time.h>

#include <mailshellc.h>

#define MAX_MSG_SIZE 20000
#define MIN_THREAD_STACK_SIZE 1048576  // 1MB

int allScores[100+1];
int showMsgScore=0;

unsigned int totalTimes=0;
unsigned int allTimes[1000+1];

unsigned int allKbs[1000+1];

char envelope[] = "HELO gozoom.com\r\nMAIL FROM: <joe@isp.com>\r\nRCPT TO <mary@isp.com>\r\nRCPT TO: sue@isp.com";

void *engine;
#ifdef WIN32
HANDLE threadPoolSem;
HINSTANCE dlhandle; 
typedef HANDLE pthread_t;
#else
void *dlhandle;
sem_t *threadPoolSem;
#endif

typedef void *(*thread_function_t)(void *);
typedef struct threadRec {
	char *fname;
	int filesize;
	int busy;
	int index;
	pthread_t thr;
	int score;
} threadRec_t;

Mailshell_constructorProc engineConstructor=NULL;
Mailshell_destructorProc engineDestructor=NULL;
Mailshell_initializeProc engineInitialize=NULL;
Mailshell_setOptionProc engineSetOption=NULL;
Mailshell_getVersionProc engineGetVersion=NULL;

MailshellMsg_constructorProc msgConstructor=NULL;
MailshellMsg_destructorProc msgDestructor=NULL;
MailshellMsg_computeScoreProc msgComputeScore=NULL;
MailshellMsg_setSmtpIPaddrProc msgSetSmtpIPaddr=NULL;
MailshellMsg_setSmtpEnvelopeProc msgSetSmtpEnvelope=NULL;

void usage() {
	fprintf(stdout, "usage: threadtest [-D configdir] [-t numthreads] [-l loops] [-v] [-m progress]\n\t\t[-regkey key] directory\n\n");
	fprintf(stdout, "Arguments:\n");
	fprintf(stdout, "  -D configdir - Optional. Directory containing rules and spamcatcher.conf. \n\tDefault is current directory.\n");
	fprintf(stdout, "  -t numthreads - Optional. Number of threads to use. Defaults to 1\n");
	fprintf(stdout, "  -l loops - Optional. Number of times to loop through messages. Defaults to 1.\n");
	fprintf(stdout, "  -v  - Optional. Flag to output score for each message. Defaults to off.\n");
	fprintf(stdout, "  -m progress - Optional. Displays number of messages processed thus far.\n\tDefaults to 10.\n");
	fprintf(stdout, "  -regkey key - Optional. Specifies the registration key.\n");
	fprintf(stdout, "  -netcheck setting - Optional. Either yes or no. Defaults to no.\n");
	fprintf(stdout, "  -use_cache setting - Optional. Either yes or no. Applies if netcheck=no.\n\t\tDefaults to yes.\n");
	fprintf(stdout, "  -verbose setting - Optional.  Either yes or no. Defaults to no.\n");
	fprintf(stdout, "  -ruleupdate setting - Optional.  Indicates number of seconds between checks.\n\t\tDefaults to 3600.\n");
	fprintf(stdout, "  -sntimeout setting - Optional. Indicates number of seconds to time out when\n\t\t");
	fprintf(stdout, "connecting to SpamCatcher Network. Defaults to 5.\n");
	fprintf(stdout, "  directory - Required. Directory containing mail messages to analyze.\n");
	exit(0);
}

void printLastError() {
#ifdef WIN32
	LPVOID errorString;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &errorString,
		0,
		NULL 
	);
	fprintf(stdout,"%s\n",errorString);
	LocalFree( errorString );
#else
	const char *error;
	if ((error = dlerror()) != NULL)  {
		fprintf(stdout,"%s\n",error);
	}
#endif
	return;

}

///////////////////////////////////////////////////////////////////////////////
// This function dynamically loads the SpamCatcher library
// at runtime
///////////////////////////////////////////////////////////////////////////////
void loadSpamCatcherLibrary() {
#ifdef WIN32
	dlhandle = LoadLibrary("winspamcatcher.dll");
#else
	dlhandle = dlopen ("libspamcatcher.so", RTLD_LAZY|RTLD_GLOBAL);
#endif
	if (!dlhandle) {
		fprintf(stdout,"Loading SpamCatcher Module failed. ");
		printLastError();
		exit(1);
	}
}

///////////////////////////////////////////////////////////////////////////////
// This function dynamically loads the the specified function
// at runtime.  It is a wrapper around the GetProcAddress function
// in Windows and the dlsym function in the *nix world.
//
///////////////////////////////////////////////////////////////////////////////
void* loadFunctionWrapper(void *dlhandle, const char *funcName) {
	void *funcPtr;
#ifdef WIN32
	funcPtr = GetProcAddress((HINSTANCE)dlhandle, funcName);
#else
	funcPtr = dlsym(dlhandle,funcName);
#endif
	if (!funcPtr) {
		fprintf(stdout,"Loading function %s failed. ",funcName);
		printLastError();
		exit(1);
	}

	return funcPtr;
}


///////////////////////////////////////////////////////////////////////////////
// This function unloads the SpamCatcher Library
///////////////////////////////////////////////////////////////////////////////
void unloadSpamCatcherLibrary() {
#ifdef WIN32
	FreeLibrary(dlhandle); 
#else
	dlclose(dlhandle); 
#endif
}


///////////////////////////////////////////////////////////////////////////////
// This function loads in all the Mailshell SpamCatcher functions
///////////////////////////////////////////////////////////////////////////////
void LoadAllFuncPointers() {
	engineConstructor = (Mailshell_constructorProc) loadFunctionWrapper(dlhandle, "Mailshell_constructor");
	engineDestructor = (Mailshell_destructorProc) loadFunctionWrapper(dlhandle, "Mailshell_destructor");
	engineInitialize = (Mailshell_initializeProc) loadFunctionWrapper(dlhandle, "Mailshell_initialize");
	engineSetOption = (Mailshell_setOptionProc) loadFunctionWrapper(dlhandle, "Mailshell_setOption");
	engineGetVersion = (Mailshell_getVersionProc) loadFunctionWrapper(dlhandle, "Mailshell_getVersion");
	msgConstructor = (MailshellMsg_constructorProc) loadFunctionWrapper(dlhandle, "MailshellMsg_constructor");
	msgDestructor = (MailshellMsg_destructorProc) loadFunctionWrapper(dlhandle, "MailshellMsg_destructor");
	msgComputeScore = (MailshellMsg_computeScoreProc) loadFunctionWrapper(dlhandle, "MailshellMsg_computeScore");
	msgSetSmtpIPaddr = (MailshellMsg_setSmtpIPaddrProc) loadFunctionWrapper(dlhandle, "MailshellMsg_setSmtpIPaddr");
	msgSetSmtpEnvelope = (MailshellMsg_setSmtpEnvelopeProc) loadFunctionWrapper(dlhandle, "MailshellMsg_setSmtpEnvelope");
}

///////////////////////////////////////////////////////////////////////////////
// Loop through the thread records to the find next available one
// Returns the index for that record.
// If all are busy then a -1 is returned
///////////////////////////////////////////////////////////////////////////////
int findUnbusy(threadRec_t* t,int size) {
	int i;
	for (i=0; i<size; i++) {
		if (t[i].busy==0) return i;
	}
	return -1;
}

#ifdef WIN32

void* scoreFile(void *ptr);
unsigned int __stdcall ScoreFileWrapper(void * arglist)
{
	scoreFile(arglist);
	return 0;
}
#endif

void* scoreFile(void *ptr) {
	char buf[MAX_MSG_SIZE];
	unsigned int score=0;
	void *msgObj;
	int elapsed=0;
	int kbs=0;
#ifdef WIN32
	unsigned int start_time;
	unsigned int end_time;
#else
	struct timeval start_time;
	struct timeval end_time;
#endif
	threadRec_t* tmp  = (threadRec_t *)ptr;

	FILE *fp;
	if ((fp = fopen(tmp->fname,"rb"))) {
		int bufLen=0;
		while (!feof(fp) && (bufLen < MAX_MSG_SIZE) ) {
			int chunk = MAX_MSG_SIZE - bufLen;
			int bytes= fread(buf+bufLen,1,chunk,fp);
			if (bytes>0) bufLen += bytes;
			else {
				break;
			}
		}
		fclose(fp);
#ifdef WIN32			
		start_time = GetTickCount(); // only supports millisecond granularity
#else
		gettimeofday(&start_time,NULL);
#endif 
		msgObj = msgConstructor(engine);
		
		if (msgObj) {
			msgSetSmtpIPaddr(msgObj,"1.2.3.4");
			msgSetSmtpEnvelope(msgObj,envelope);
			msgComputeScore(msgObj,buf,bufLen,&score);
			msgDestructor(msgObj);
		}
#ifdef WIN32
		end_time = GetTickCount();
		elapsed = end_time - start_time;
#else
		gettimeofday(&end_time,NULL);
		
		elapsed = (end_time.tv_sec - start_time.tv_sec) * 1000000 + 
			(end_time.tv_usec - start_time.tv_usec);
		elapsed /= 1000;  // Convert to milliseconds
#endif
		if (elapsed<=0) elapsed=1; //Force to at least 1ms
		if (elapsed < 1000) allTimes[elapsed]++;
		else allTimes[1000]++; // Messages which take at least 1 second
		totalTimes+=elapsed;
		
		// Filesize is in bytes/ elapsed in milliseconds
		// Straight division will gived kilobytes/second
		kbs = tmp->filesize / elapsed;
		if (kbs<=0) kbs=0;
		if (kbs < 1000) allKbs[kbs]++;
		else allKbs[1000]++; // Messages  processed at greater than 1MB/s
	}
	
	allScores[score]++;
	if (showMsgScore) {
		fprintf(stdout,"File: %s\tScore: %d\n",tmp->fname,score);
	}

	tmp->busy=0;
#ifdef WIN32	
	ReleaseSemaphore(threadPoolSem, 1, NULL);
	return 0;
#else
	sem_post(threadPoolSem);
	pthread_exit(NULL);
#endif
}

void showStats(unsigned int totalMsgs, int reportMod, unsigned int totalBytes, 
			   time_t *startTime, time_t* initTime, time_t* endTime){
	int subtotalMsgs;
	int binTotal;
	int totalTime=0;
	double elapsed;
	unsigned long kb;
	int latencyHisto[101];
	int kbsHisto[101];
	int pct=0;
	int i=0;
	int j=0;
	int prevPct;
	double avgConc = 1;
	if (totalMsgs<=0) return;
	subtotalMsgs=0;
	
	fprintf(stdout,"Done.\n\n");
	fprintf(stdout,"SCORE SUMMARY\n\n");
	fprintf(stdout,"Total Messages Processed: %d\n",totalMsgs);
	fprintf(stdout,"Histogram:\n");
	fprintf(stdout,"Score\tNumMsgs\tCumul. Pct.\n");
	fprintf(stdout,"-----\t-------\t---------\n");
	binTotal=0;
	if (reportMod<=0) reportMod=1;
	for (j=100; j >=0; j--) {
		subtotalMsgs += allScores[j];
		binTotal += allScores[j];
		if (j%reportMod == 0) {
			int pct = 100 * subtotalMsgs / totalMsgs;
			fprintf(stdout,"%d\t%d\t%d\n",j,binTotal,pct);
			binTotal=0;
		}
	}
	
	fprintf(stdout,"\ncurrent time is : %s\n\n", ctime(endTime));
	elapsed = difftime(*initTime, *startTime);

	fprintf(stdout,"PERFORMANCE SUMMARY\n\n");
	fprintf(stdout,"Time to initialize engine: %0.2g seconds\n",elapsed);
			
	elapsed = difftime(*endTime, *initTime);
	fprintf(stdout,"Time to process messages: %0.2g seconds\n\n",elapsed);

	kb = totalBytes / 1024;
	if (elapsed <=0 ) {
		fprintf(stdout,"More messages are required to generate throughput statistics.\n");
		return;
	}

	fprintf(stdout,"Total messages processed: %d\n",totalMsgs);
	fprintf(stdout,"Throughput: %d/%g = %0.2g messages per second\n",totalMsgs,elapsed,(totalMsgs/elapsed));
	avgConc = totalTimes/(elapsed*1000);
	fprintf(stdout,"\nAvg. Concurrency: %d/%0.4g = %0.4g\n",totalTimes,elapsed*1000,avgConc);
	fprintf(stdout,"\nTotal size of analyzed messages: %d kilobytes\n",kb);
	fprintf(stdout,"%d/%0.4g = %0.4G kilobytes per second\n",kb,elapsed,(kb/elapsed));
	
	// Compute the Delay Histogram
	subtotalMsgs=0;
	prevPct=0;
	for (i=0; i<1000; i++) {
		if (allTimes[i]<=0) continue;
		subtotalMsgs += allTimes[i];
		pct = 100 * subtotalMsgs / totalMsgs;
		for (j=pct; j>prevPct; j--) {
			latencyHisto[j] = i;
		}
		prevPct=pct;
	}
	for (j=100; j>prevPct; j--) {
		latencyHisto[j]=latencyHisto[prevPct];
	}
	
	// Display the Delay Histogram
	fprintf(stdout,"\n\nAvg. Latency: %d/%d = %d milliseconds per message\n",totalTimes,totalMsgs,(totalTimes/totalMsgs));
	fprintf(stdout,"\nLatency Histogram\n");
	fprintf(stdout,"\nPct\tMilliseconds\n");
	fprintf(stdout,"---\t------------\n");
	for (i=99; i>0; i--) {
		if (i>90 || i % 10 ==0) fprintf(stdout,"%d\t%d\n",i,latencyHisto[i]);
	}


	// Compute the Throughput Histogram (Kb/s)
	subtotalMsgs=0;
	prevPct=0;
	for (i=999; i>0; i--) {
		if (allKbs[i]<=0) continue;
		subtotalMsgs += allKbs[i];
		pct = 100 * subtotalMsgs / totalMsgs;
		for (j=pct; j>prevPct; j--) {
			kbsHisto[j] = (int)(i * avgConc);
		}
		prevPct=pct;
	}
	for (j=100; j>prevPct; j--) {
		kbsHisto[j]=kbsHisto[prevPct];
	}

	// Display the Delay Histogram
	fprintf(stdout,"\nKb/s Histogram\n");
	fprintf(stdout,"\nPct\tKb/s\n");
	fprintf(stdout,"---\t------------\n");
	for (i=99; i>0; i--) {
		if (i>90 || i % 10 ==0) fprintf(stdout,"%d\t%d\n",i,kbsHisto[i]);
	}
}

int main (int argc, char **argv) 
{
	threadRec_t *threadRecs;
	int numThreads = 1;
	int sleeptime=0;
	int bigLoops=1;
	int modbase=10;
	int reportMod=1;
	int i=0;
	int j=0;
	int numInst = 0;
	int rc = 0;
	int msgnum=0;
	unsigned int totalMsgs=0;
	char fname[1024];
	char vbuf[40];
	unsigned int vbufSize=40;
	char *confdir = NULL;
	char *msgdir = NULL;
	time_t initTime;
	time_t startTime;
	time_t endTime;
	int filesize;
	unsigned totalBytes = 0;
#ifndef WIN32
	pthread_attr_t pta;
	size_t stack_size=0;
#endif

#ifdef WIN32
	unsigned int thrid;
#else
	struct dirent *de;
	struct stat statbuf;
#endif
	
	char *regkey = NULL;
	char *netcheck = NULL;
	char *verbose = NULL;
	char *ruleupdate = NULL;
	char *use_cache = NULL;
	char *sntimeout = NULL;


	confdir = strdup(".");
	// Parse command line options
	for (i=1; i < argc; i++) {
		char *arg = argv[i];
		if (!strcmp(arg,"-D")) {
			i++;
			if (i>=argc) usage();

			if (confdir) {
				free(confdir);
			}
			confdir = strdup(argv[i]);
		} else if (!strcmp(arg,"-t")) {
			i++;
			if (i>=argc) usage();
			numThreads = atoi(argv[i]);
		} else if (!strcmp(arg,"-s")) {
			i++;
			if (i>=argc) usage();
			sleeptime = atoi(argv[i]);
		} else if (!strcmp(arg,"-l")) {
			i++;
			if (i>=argc) usage();
			bigLoops = atoi(argv[i]);
		} else if (!strcmp(arg,"-m")) {
			i++;
			if (i>=argc) usage();
			modbase = atoi(argv[i]);
		} else if (!strcmp(arg,"-r")) {
			i++;
			if (i>=argc) usage();
			reportMod = atoi(argv[i]);
		} else if (!strcmp(arg,"-v")) {
			showMsgScore=1;
		} else if (!strcmp(arg, "-regkey")) {
			i++;
			regkey = argv[i];
		} else if (!strcmp(arg, "-netcheck")) {
			i++;
			netcheck = argv[i];
		} else if (!strcmp(arg, "-verbose")) {
			i++;
			verbose = argv[i];
		} else if (!strcmp(arg, "-ruleupdate")) {
			i++;
			ruleupdate = argv[i];
		} else if (!strcmp(arg, "-use_cache")) {
			i++;
			use_cache = argv[i];
		} else if (!strcmp(arg, "-sntimeout")) {
			i++;
			sntimeout = argv[i];
		} else {
			if (msgdir) free(msgdir);
			msgdir = strdup(argv[i]);
		}
	}

#ifdef WIN32
	threadPoolSem = CreateSemaphore(
	    NULL,   // no security attributes
	    numThreads,   // initial count
		numThreads,   // maximum count
		NULL);  // unnamed semaphore

#else
	threadPoolSem = (sem_t *) malloc(sizeof(sem_t));
	sem_init(threadPoolSem,0,numThreads);
#endif

	threadRecs = (threadRec_t *) malloc(numThreads*sizeof(threadRec_t));
	for(j=0; j<numThreads; j++) {
		threadRecs[j].busy=0;
		threadRecs[j].index=j;
		threadRecs[j].fname=NULL;
		threadRecs[j].thr=0;
	}

	// Initialize Score Array
	for(j=0; j<=100; j++) {
		allScores[j]=0;
	}

	// Initialize Elapsed Time Array
	for(j=0; j<1001; j++) {
		allTimes[j]=0;
	}

	// Initialize Kilobytes/Second Time Array
	for(j=0; j<1001; j++) {
		allKbs[j]=0;
	}

	if (!msgdir) {
		usage();
	}


	i=0;
	
	time(&startTime);
	fprintf(stdout,"current time is: %s\n",ctime(&startTime));
	
	loadSpamCatcherLibrary();
	LoadAllFuncPointers();
	fprintf(stdout,"Instantiating engine\n");
	engine = engineConstructor(confdir);

	if (regkey != NULL)
		engineSetOption(engine, "regkey", regkey);

	if (netcheck != NULL)
		engineSetOption(engine,"netcheck", netcheck);

	if (ruleupdate != NULL)
		engineSetOption(engine,"ruleupdate", ruleupdate);

	if (verbose != NULL)
		engineSetOption(engine,"verbose", verbose);

	if (sntimeout != NULL)
		engineSetOption(engine,"sntimeout", sntimeout);

	if (use_cache != NULL)
		engineSetOption(engine,"use_cache", use_cache);


#ifndef WIN32
	// Ensure that thread stack size is at least 1MB
	// FreeBSD has a default thread stack size of 64KB which can be too small
	pthread_attr_init(&pta);
	pthread_attr_getstacksize(&pta,&stack_size);
	if (stack_size < MIN_THREAD_STACK_SIZE) {
		fprintf(stdout,"Adjusting minimum thread stack size from %d bytes to %d bytes\n\n",stack_size,MIN_THREAD_STACK_SIZE);
		stack_size = MIN_THREAD_STACK_SIZE;
		pthread_attr_setstacksize(&pta,stack_size);
	}
#endif
	engineSetOption(engine,"pcre_match_limit","10000");

	// determine Mailshell SDK version
	engineGetVersion(engine,vbuf, &vbufSize);

	fprintf(stdout,"SDK version: %s\n",vbuf);

	msgnum=0;

	fprintf(stdout,"\nInitializing Mailshell SpamCatcher . . . \n");
	rc = engineInitialize(engine);
	switch(rc) {
	case MAILSHELL_OK:
		break;
	case MAILSHELL_LICENSE_INVALID:
		fprintf(stdout,"ERROR: Mailshell License is invalid.\n");
		exit(6);
		break;
	case MAILSHELL_LICENSE_EXPIRED:
		fprintf(stdout,"ERROR: Mailshell License is expired.\n");
		exit(6);
		break;
	case MAILSHELL_INVALID_CONFIG_DIR:
		fprintf(stdout,"ERROR: Invalid Configuration Directory.\n");
		exit(6);
		break;
	case MAILSHELL_NO_RULES_LOADED:
		fprintf(stdout,"ERROR: No Rules Loaded.\n");
		exit(6);
		break;
	default: 
		fprintf(stdout,"ERROR: Unknown Error occured.\n");
		exit(6);
		break;
	}

	totalMsgs=0;

	time(&initTime);
	fprintf(stdout,"initialization completed at: %s\n",ctime(&initTime));

	for (i=0;  i <bigLoops; i++) {

#ifdef WIN32
		struct _finddata_t c_file;
		long hFile;
		char specifier[1024];
		_snprintf(specifier,1024,"%s\\*.*",msgdir);

		if( (hFile = _findfirst(specifier,&c_file))==-1) {
			fprintf(stdout, "ERROR: no messages found. \n");
			continue;
		}
		
		while( _findnext( hFile, &c_file ) == 0 )
		{
			int threadIndex=-1;
			if (c_file.attrib & _A_SUBDIR) 
				continue;
			
			_snprintf(fname,1024,"%s\\%s",msgdir,c_file.name);
			filesize = c_file.size;
#else			
		DIR *thedir = opendir(msgdir);
		if (!thedir) {
			fprintf(stdout, "ERROR: no messages found. \n");
			continue;
		}
		
		while (de=readdir(thedir)) {
			int threadIndex=-1;
			
			snprintf(fname,1024,"%s/%s",msgdir,de->d_name);
			
			if (stat(fname,&statbuf)!=0) continue;
			if (S_ISDIR(statbuf.st_mode)) continue;
			filesize = statbuf.st_size;
			
#endif
			while (threadIndex==-1) {
#ifdef WIN32
				WaitForSingleObject(threadPoolSem, INFINITE);
#else
				sem_wait(threadPoolSem);// Wait if all threads busy
#endif
				// Find the first unbusy thread
				threadIndex  = findUnbusy(threadRecs,numThreads);
#ifdef WIN32
				if (threadIndex==-1) ReleaseSemaphore(threadPoolSem, 1, NULL);
#else
				if (threadIndex==-1) sem_post(threadPoolSem);
#endif
			}
			if (modbase!=0 && totalMsgs%modbase==0 && totalMsgs!=0) {
				fprintf(stdout,"Progress Meter: %d Messages\n",totalMsgs);
			}
			
			// Re-Claim prior resources
			if (threadRecs[threadIndex].thr != 0) {
#ifdef WIN32
				WaitForSingleObject(threadRecs[threadIndex].thr, INFINITE);
				CloseHandle(threadRecs[threadIndex].thr);
#else
				pthread_join(threadRecs[threadIndex].thr, NULL);
#endif
				threadRecs[threadIndex].thr=0;
			}
			totalMsgs++;
			totalBytes += filesize;
			
			threadRecs[threadIndex].busy=1;
			threadRecs[threadIndex].filesize=filesize;
			if (threadRecs[threadIndex].fname) {
				free(threadRecs[threadIndex].fname);
				threadRecs[threadIndex].fname=NULL;
			}
			threadRecs[threadIndex].fname=strdup(fname);
#ifdef WIN32
			threadRecs[threadIndex].thr = (HANDLE)_beginthreadex(NULL, 0, ScoreFileWrapper, 
															(void *)&threadRecs[threadIndex], 0, 
															&thrid); 
#else
			pthread_create(&(threadRecs[threadIndex].thr), &pta,
						   scoreFile, 
						   (void *)&threadRecs[threadIndex]);
#endif
		}
#ifdef WIN32
		_findclose( hFile );
#else
		closedir(thedir);
#endif
	}
	// Wait for all threads
	for (i=0; i < numThreads; i++) {
		if (threadRecs[i].thr != 0) {
#ifdef WIN32
			WaitForSingleObject(threadRecs[i].thr, INFINITE);
			CloseHandle(threadRecs[i].thr);
#else
			pthread_join(threadRecs[i].thr,NULL);
#endif
			threadRecs[i].thr = 0;
			if (threadRecs[i].fname) {
				free(threadRecs[i].fname);
				threadRecs[i].fname=NULL;
			}
		}
	}

	if (engine) engineDestructor(engine);
	engine=NULL;
	time(&endTime);
	
	showStats(totalMsgs,reportMod,totalBytes,&startTime,&initTime,&endTime);

	if (sleeptime>0) {
		fprintf(stdout,"ALL threads done, now sleeping for %d\n",sleeptime);
	}

#ifdef WIN32
	Sleep(sleeptime);
#else
	sleep(sleeptime);
#endif
	if (threadRecs) free(threadRecs); threadRecs=NULL;
	unloadSpamCatcherLibrary();
	
	if (confdir) 
		free(confdir);

	exit(0);
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
// This example application uses multiple threads to analyze a directory of
// messages. The output will be a score for each message, along with 
// a summary of the results.
// This example uses the Mailshell SDK's C interface.
// Syntax: threadtest -D <configdir> -t <numthreads> -l <loops> -showstatus
//			-m <progress> -regkey <regkey> 
//			-netcheck <setting> -use_cache <setting> -verbose <setting> 
//			-ruleupdate <setting> -sntimeout <setting>  -smtpip <smtp ip address>
//			-smtpenvelope <smtp envelope> <option=value> <directory>
//
// Arguments:  
//  configdir - Required. Directory containing rules and spamcatcher.conf
//  directory - Required. Directory containing mail messages to analyze.
//  numthreads - Optional. Number of threads to use. Defaults to 100.
//  loops - Optional. Number of times to loop through messages. Defaults to 1.
//  progress - Optional. Number of messages after which total number of processed 
//		messages thus far is shown. Defaults to 10
//  v  - Optional. Flag to output score for each message. Defaults to off.
//  showstatus - Optional.  same as -v option.
//  regkey - Optional. registration key
//  netcheck setting - Optional. Either yes or no. Defaults to no.
//  use_cache setting - Optional. Either yes or no. Applies if netcheck=no. 
//		Defaults to yes.
//  verbose setting - Optional.  Either yes or no. Defaults to no.
//  ruleupdate setting - Optional.  Indicates number of seconds between checks.
//		Defaults to 3600.
//  sntimeout setting - Optional. Indicates number of seconds to time out when
//		connecting to SpamCatcher Network. Defaults to 5.
//  smtpip - Optional. An SMTP IP address that will be passed to setSmtpIPaddr()
//  smtpenvelope - Optional. An SMTP envelope that will be passed to setSmtpEnvelope()
//		Example: -smtpenvelope "HELO domain.com\nMAIL FROM:<admin@domain.com>"
//  option=value - Optional. Set any option using this format
//
// Example:  threadtest -D conf messagedir
///////////////////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef WIN32
#include <io.h>
#include <process.h>
#include <windows.h>

#else
#include <dirent.h>
#include <unistd.h>
#include <sys/time.h>
#include <pthread.h>
#include <semaphore.h>
#include <errno.h>
#endif

#include <stdio.h>
#include <string.h>

#include <time.h>
#include <locale.h>
#include <mailshellc.h>
#include <ctype.h>

//#define MAX_SCAN_SIZE 20000
//#define MAX_SCAN_SIZE 100000
#define MAX_MSG_SIZE 1048576  // 1MB
//#define MIN_THREAD_STACK_SIZE 2097152  // 2MB
#define MIN_THREAD_STACK_SIZE 1048576  // 1MB

int allScores[100+1];
int showMsgScore=0;
int msg_bufsize=100000;
unsigned int totalTimes=0;
unsigned int allTimes[1000+1];

unsigned int allKbs[1000+1];
int numThreads = 10;

// This is an example of a typical SMTP Envelope
// char envelope[] = "HELO domain.com\r\nMAIL FROM: <joe@isp.com>\r\nRCPT TO <mary@isp.com>\r\nRCPT TO: sue@isp.com";

char *smtpip = NULL;
char *smtpenvelope = NULL;
int doGreylistCheck=0;
char *programName;
#define TMPBUFSIZE 4096

void* engine;
#ifdef WIN32
HANDLE threadPoolSem=NULL;
typedef HANDLE pthread_t;
#else
sem_t *threadPoolSem;
#endif

typedef void *(*thread_function_t)(void *);
typedef struct threadRec {
  char *fname;
  int filesize;
  int busy;
  int index;
  pthread_t thr;
  int score;
} threadRec_t;
void cleanupAndExit(int exitcode);

#if __GLIBC__ > 2 || (__GLIBC__ == 2 && __GLIBC_MINOR__ > 2)
int __ctype_tolower(int x) { return tolower(x); }
int __ctype_toupper(int x) { return toupper(x); }
__const unsigned short int *__ctype_b;
void ctSetup()
{
  __ctype_b = *(__ctype_b_loc());
}
#endif
int ruleRetrieveProgress(void *opaque,int ruleFileIndex, int dltotal,int dlnow,int ulnow,int ultotal) {
  fprintf(stdout,"RetrieveRule Progress sc%d.bin %d/%d, UL %d/%d\n",ruleFileIndex,dlnow,dltotal,ulnow,ultotal);
  return 0;
}

void ruleUpdateNotification(void *opaque) {
  void *e = opaque;
  char versionBuffer[64];
  int i;
  int rc;
  time_t lastUpdateTime;
  for(i=1; i<= 23; i++) {    
    rc = Mailshell_getRuleVersion(e,i,versionBuffer);
	  fprintf(stdout,"sc%d.bin has version %s with return code %d \n",i,versionBuffer,rc);
    if (rc==MAILSHELL_OK) {
      if (versionBuffer[0]!=0) {
	fprintf(stdout,"sc%d.bin has version %s\n",i,versionBuffer);
      }
    } else {
      fprintf(stdout,"Error %d when getting rule version for sc%d.bin\n",rc,i);
    }
  }
  rc = Mailshell_getLastRuleUpdateTime(e,&lastUpdateTime);
  if (rc==MAILSHELL_OK) {
    fprintf(stdout,"Rules last updated %s\n",ctime(&lastUpdateTime));
  } else {
    fprintf(stdout,"Error %d when getting last rule update time\n",rc);
  }
}

void usage() {
  fprintf(stdout, "usage: %s [-D configdir] [-t numthreads] [-retrieverules yes|no]\n\t\t[-l loops] [-showstatus] \n\t\t", programName);
  fprintf(stdout, "[-m progress] [-regkey key] [-netcheck yes|no] \n\t\t");
  fprintf(stdout, "[-use_cache setting] [-verbose setting] [-ruleupdate setting]\n\t\t");
  fprintf(stdout, "[-sntimeout setting] [-smtpip ipaddress]\n\t\t");
  fprintf(stdout, "[-smtpenvelope envelope] [-b bufsize] [-locale setting] [option=value]\n\t\t");
  fprintf(stdout, "directory\n\n");
  fprintf(stdout, "Arguments:\n");
  fprintf(stdout, "  -D configdir - Optional. Directory containing rules and spamcatcher.conf. \n\tDefault is current directory.\n");
  fprintf(stdout, "  -t numthreads - Optional. Number of threads to use. Defaults to 10\n");
  fprintf(stdout, "  -retrieverules yes|no - Optional. Force rule retrieval. Either yes or no. \n\tDefaults to yes\n");
  fprintf(stdout, "  -l loops - Optional. Number of times to loop through messages. Defaults to 1.\n");
  fprintf(stdout, "  -showstatus - Optional.  Flag to output score for each message and \n\tdisplay current settings. Defaults to off\n");
  fprintf(stdout, "  -m progress - Optional. Displays number of messages processed thus far.\n\tDefaults to 10.\n");
  fprintf(stdout, "  -b bufsize  - Optional. Number of bytes to read from message into computeScore buffer.\n\tDefaults to 100000.\n");
  fprintf(stdout, "  -locale  - Optional. specify a locale.  Defaults to \"C\".\n");
  fprintf(stdout, "  -regkey key - Optional. Specifies the registration key.\n");
  fprintf(stdout, "  -netcheck setting - Optional. Either yes or no. Defaults to no.\n");
  fprintf(stdout, "  -use_cache setting - Optional. Either yes or no. Applies if netcheck=no.\n\t\tDefaults to yes.\n");
  fprintf(stdout, "  -verbose setting - Optional.  Either yes or no. Defaults to no.\n");
  fprintf(stdout, "  -ruleupdate setting - Optional.  Indicates number of seconds between checks.\n\t\tDefaults to 3600.\n");
  fprintf(stdout, "  -sntimeout setting - Optional. Indicates number of seconds to time out when\n\t\t");
  fprintf(stdout, "connecting to SpamCatcher Network. Defaults to 5.\n");
  fprintf(stdout, "  -smtpip ipaddress - Optional. An SMTP IP address that will be passed\n\tto setSmtpIPaddr()\n");
  fprintf(stdout, "  -smtpenvelope envelope - Optional. An SMTP envelope that will be passed\n\tto setSmtpEnvelope()\n");
  fprintf(stdout, "	Example: -smtpenvelope \"HELO domain.com\\nMAIL FROM:<admin@domain.com>\"\n");
  fprintf(stdout, "  option=value - Optional. Set any option using this format.\n");
  fprintf(stdout, "  directory - Required. Directory containing mail messages to analyze.\n");
  cleanupAndExit(0);
}

///////////////////////////////////////////////////////////////////////////////
// Loop through the thread records to the find next available one
// Returns the index for that record.
// If all are busy then a -1 is returned
///////////////////////////////////////////////////////////////////////////////
int findUnbusy(threadRec_t* t,int size) {
  int i;
  for (i=0; i<size; i++) {
    if (t[i].busy==0) return i;
  }
  return -1;
}

#ifdef WIN32

void* scoreFile(void *ptr);
unsigned int __stdcall ScoreFileWrapper(void * arglist)
{
  scoreFile(arglist);
  return 0;
}
#endif

void* scoreFile(void *ptr) {
  char *buf=NULL;
  unsigned int score=0;
  int elapsed=0;
  int kbs=0;
  void *msg;
  const char *info_attrs[] = {"spamcatcher1", "scoring_explanation","scoring_category","scoring_summary","scoring_summary_short",
                              "rbl_summary","dns_info","charsets","countries","spf_status","phishing_status",
                              "MSBL","msgbl_type_zero","msgbl","blueprint","msgbl_type_three","md5_5k","blueprint_optimized","shingles","dkim_info",
                              "empty_body","defer", "lua_summary","malware","newsletter","fraud","adult","attach_name_md5_5k"};

  int info_attrs_size = sizeof(info_attrs)/sizeof(char *);
  int i;
#ifdef WIN32
  unsigned int start_time;
  unsigned int end_time;
#else
  struct timeval start_time;
  struct timeval end_time;
#endif
  threadRec_t* tmp  = (threadRec_t *)ptr;
  int rc=0;
  FILE *fp;
  char *extraInfoBuffer=NULL;
  unsigned int extraInfoBufferSize = TMPBUFSIZE;
  unsigned int tmpInfoBufferSize=extraInfoBufferSize;
  int numBytesToRead = tmp->filesize;
  // To reduce memory usage, don't read more than MAX_MSG_SIZE bytes
  if (numBytesToRead > msg_bufsize) {
    numBytesToRead = msg_bufsize;
  }
  if (showMsgScore) {
    fprintf(stdout,"File: %s\tOpening:\n",tmp->fname);
    fflush(stdout);
  }
  buf = (char *) malloc(numBytesToRead* sizeof(char));

  if (buf && (fp = fopen(tmp->fname,"rb"))) {
    int bufLen=0;
    while (!feof(fp) && (bufLen < numBytesToRead) ) {
      int chunk = numBytesToRead - bufLen;
      int bytes= fread(buf+bufLen,1,chunk,fp);
      if (bytes>0) bufLen += bytes;
      else {
	break;
      }
    }
    fclose(fp);
#ifdef WIN32			
    start_time = GetTickCount(); // only supports millisecond granularity
#else
    gettimeofday(&start_time,NULL);
#endif 

    msg = MailshellMsg_constructor(engine);

    //Mailshell_reloadOptions(engine);
    // Here we demonstrate how Mailshell_setSmtpIPaddr()
    // and MailshellMsg_setSmtpEnvelope would be used.
    //
    if (smtpip != NULL)
      MailshellMsg_setSmtpIPaddr(msg, smtpip);

    if (smtpenvelope != NULL) {
      //Replace "\n" with newline character
      char *envptr1 = smtpenvelope;
      char *envptr2 = smtpenvelope;
      while (*envptr1) {
        if (*envptr1=='\\' && *(envptr1+1)=='n') {
          *envptr2++ = '\n';
          envptr1 += 2;
        } else {
          *envptr2++ = *envptr1++;
        }
      }
      *envptr2=0;
      MailshellMsg_setSmtpEnvelope(msg, smtpenvelope);
    }
    if (doGreylistCheck) {
      rc = MailshellMsg_greylistCheck(msg);
      if (rc==0) {
	fprintf(stdout,"File: %s\tGreylist TMP Fail on IP: %s, Envelope: %s\n",tmp->fname,smtpip,smtpenvelope);
	fflush(stdout);
      } else if (rc==1) {
	fprintf(stdout,"File: %s\tGreylist Pass on IP: %s, Envelope: %s\n",tmp->fname,smtpip,smtpenvelope);
	fflush(stdout);
      }
    }
    if (!doGreylistCheck || rc ==1) {
      rc = MailshellMsg_computeScore(msg,buf,bufLen,&score);
      if (msg) {

	if (showMsgScore) {
	  fprintf(stdout,"File: %s\tComputeScore Result code is %d, score is %d\n",tmp->fname,rc,score);
	  fflush(stdout);

	  extraInfoBuffer=(char *)malloc(extraInfoBufferSize*sizeof(char));
	  if (!extraInfoBuffer) {
	    fprintf(stdout, "File: %s\tMalloc failed for extraInfoBuffer\n",tmp->fname);
	    cleanupAndExit(3);
	  }

	  for (i=0; i < info_attrs_size; i++) {
	    while (1) {
	      tmpInfoBufferSize=extraInfoBufferSize;
	      rc =MailshellMsg_getExtraInfo(msg, info_attrs[i], extraInfoBuffer, &tmpInfoBufferSize);
	      if (rc==MAILSHELL_OK) {
		fprintf(stdout, "File: %s\tExtra info %s: %s\n", tmp->fname, info_attrs[i],extraInfoBuffer);
		break;
	      } else if (rc==MAILSHELL_BUFFER_TOO_SMALL) {
		//Resize the extraInfoBuffer
		if (extraInfoBuffer) free(extraInfoBuffer);
		extraInfoBuffer = (char *) malloc(tmpInfoBufferSize*sizeof(char));
		if (!extraInfoBuffer) {
		  fprintf(stdout, "File: %s\tMalloc failed for extraInfoBuffer\n",tmp->fname);
		  cleanupAndExit(3);
		}
		extraInfoBufferSize=tmpInfoBufferSize;
	      } else {
		fprintf(stdout, "File: %s\tMailshellMsg_getExtraInfo for %s failed with code %d\n", tmp->fname, info_attrs[i],rc);
		break;
	      }
	    }
	  }
	  if (extraInfoBuffer) free(extraInfoBuffer);
	}
      }
    }
    if (msg) MailshellMsg_destructor(msg);
#ifdef WIN32
    end_time = GetTickCount();
    elapsed = end_time - start_time;
#else
    gettimeofday(&end_time,NULL);
		
    elapsed = (end_time.tv_sec - start_time.tv_sec) * 1000000 + 
      (end_time.tv_usec - start_time.tv_usec);
    elapsed /= 1000;  // Convert to milliseconds
#endif
    if (elapsed<=0) elapsed=1; //Force to at least 1ms
    if (elapsed < 1000) allTimes[elapsed]++;
    else allTimes[1000]++; // Messages which take at least 1 second
    totalTimes+=elapsed;
		
    // Filesize is in bytes/ elapsed in milliseconds
    // Straight division will gived kilobytes/second
    kbs = tmp->filesize / elapsed;
    if (kbs<=0) kbs=0;
    if (kbs < 1000) allKbs[kbs]++;
    else allKbs[1000]++; // Messages  processed at greater than 1MB/s
    if (buf) free(buf); 
    buf=NULL;
  }

  if (score>=0&&score <=100) {
    allScores[score]++;
  }
  if (showMsgScore) {
    fprintf(stdout,"File: %s\tScore: %d\n\n",tmp->fname,score);
  }

  tmp->busy=0;
#ifdef WIN32	
  ReleaseSemaphore(threadPoolSem, 1, NULL);
  return 0;
#else
  sem_post(threadPoolSem);
  pthread_exit(NULL);
#endif
}

void showStats(unsigned int totalMsgs, int reportMod, unsigned int totalBytes, 
	       time_t *initStartTime, time_t* initEndTime, time_t* scanStartTime, time_t* scanEndTime,
	       char *verbose){
  int subtotalMsgs;
  int binTotal;
  int totalTime=0;
  double elapsed;
  unsigned long kb;
  int latencyHisto[101];
  int kbsHisto[101];
  int pct=0;
  int i=0;
  int j=0;
  int prevPct;
  double avgConc = 1;
  if (totalMsgs<=0) return;
  subtotalMsgs=0;
	
  fprintf(stdout,"Done.\n\n");
  fprintf(stdout,"SCORE SUMMARY\n\n");
  fprintf(stdout,"Total Messages Processed: %d\n",totalMsgs);
  fprintf(stdout,"Histogram:\n");
  fprintf(stdout,"Score\tNumMsgs\tSubtotal\tCumul. Pct.\n");
  fprintf(stdout,"-----\t-------\t--------\t-----------\n");
  binTotal=0;
  if (reportMod<=0) reportMod=1;
  for (j=100; j >=0; j--) {
    subtotalMsgs += allScores[j];
    binTotal += allScores[j];
    if (j%reportMod == 0) {
      double pct = 100.0 * subtotalMsgs / totalMsgs;
      fprintf(stdout,"%d\t%d\t%d\t\t%0.1f\n",j,binTotal,subtotalMsgs,pct);
      binTotal=0;
    }
  }
  memset(kbsHisto,0,sizeof(kbsHisto));
	
  if (verbose != NULL) {
    fprintf(stdout,"CSV:");
    subtotalMsgs=0;
    binTotal=0;
    for (j=100; j >=0; j--) {
      subtotalMsgs += allScores[j];
      binTotal += allScores[j];
      if (j%reportMod == 0) {
	double pct = 100.0 * subtotalMsgs / totalMsgs;
	fprintf(stdout,"%0.1f",pct);
	binTotal=0;
      }
      fprintf(stdout,",");
    }
    elapsed = difftime(*scanEndTime, *scanStartTime);
    fprintf(stdout,"%0.2g\n",(totalMsgs/elapsed));
  }
  
  fprintf(stdout,"\ncurrent time is : %s\n\n", ctime(scanEndTime));
  elapsed = difftime(*initEndTime, *initStartTime);

  fprintf(stdout,"PERFORMANCE SUMMARY\n\n");
  fprintf(stdout,"Time to initialize engine: %0.4g seconds\n",elapsed);
			
  elapsed = difftime(*scanEndTime, *scanStartTime);
  fprintf(stdout,"Time to process messages: %0.4g seconds\n\n",elapsed);

  kb = totalBytes / 1024;
  if (elapsed <=0 ) {
    fprintf(stdout,"More messages are required to generate throughput statistics.\n");
    return;
  }

  fprintf(stdout,"Total messages processed: %d\n",totalMsgs);
  fprintf(stdout,"Throughput: %d/%0.4g = %4g messages per second\n",totalMsgs,elapsed,(totalMsgs/elapsed));
  avgConc = totalTimes/(elapsed*1000);
  fprintf(stdout,"\nAvg. Concurrency: %d/%0.4g = %0.4g\n",totalTimes,elapsed*1000,avgConc);
  fprintf(stdout,"\nTotal size of analyzed messages: %lu kilobytes\n",kb);
  fprintf(stdout,"%lu/%0.4g = %0.4G kilobytes per second\n",kb,elapsed,(kb/elapsed));
	
  // Compute the Delay Histogram
  subtotalMsgs=0;
  prevPct=0;
  memset(&latencyHisto,0,sizeof(latencyHisto));

  for (i=0; i<1000; i++) {
    if (allTimes[i]<=0) continue;
    subtotalMsgs += allTimes[i];
    pct = 100 * subtotalMsgs / totalMsgs;
    for (j=pct; j>prevPct; j--) {
      latencyHisto[j] = i;
    }
    prevPct=pct;
  }
  for (j=100; j>prevPct; j--) {
    latencyHisto[j]=latencyHisto[prevPct];
  }
	
  // Display the Delay Histogram
  fprintf(stdout,"\n\nAvg. Latency: %d/%d = %d milliseconds per message\n",totalTimes,totalMsgs,(totalTimes/totalMsgs));
  fprintf(stdout,"\nLatency Histogram\n");
  fprintf(stdout,"\nPct\tMilliseconds\n");
  fprintf(stdout,"---\t------------\n");
  for (i=99; i>0; i--) {
    if (i>90 || i % 10 ==0) fprintf(stdout,"%d\t%d\n",i,latencyHisto[i]);
  }


  // Compute the Throughput Histogram (Kb/s)
  subtotalMsgs=0;
  prevPct=0;
  for (i=999; i>0; i--) {
    if (allKbs[i]<=0) continue;
    subtotalMsgs += allKbs[i];
    pct = 100 * subtotalMsgs / totalMsgs;
    for (j=pct; j>prevPct; j--) {
      kbsHisto[j] = (int)(i * avgConc);
    }
    prevPct=pct;
  }
  for (j=100; j>prevPct; j--) {
    kbsHisto[j]=kbsHisto[prevPct];
  }

  // Display the Delay Histogram
  fprintf(stdout,"\nKb/s Histogram\n");
  fprintf(stdout,"\nPct\tKb/s\n");
  fprintf(stdout,"---\t------------\n");
  for (i=99; i>0; i--) {
    if (i>90 || i % 10 ==0) fprintf(stdout,"%d\t%d\n",i,kbsHisto[i]);
  }
}

// display setting for each option
void showCurrentOptions() {
	const char* options[] = {
		"approved_domain_list",
		"approved_ip_list",
		"auto_training_threshold",
		"blocked_charset_list",
		"blocked_country_list",
		"blocked_domain_list",
		"blocked_ip_list",
		"content_type",
		"convert_unicode",
		"custom_rules_list",
		"dbg_logfile",
		"dnsbl_list",
		"dnsbl_max_domains",
		"dnsbl_multihit",
		"dnsbl_threshold",
		"dnsbl_timeout",
		"dnscache_dns_server",
		"dnscache_enable_filecache",
		"dnscache_max_entries",
		"dnscache_min_ttl",
		"enable_all_spf",
		"enable_auto_update_data_thread",
		"enable_auto_update_engine_thread",
		"enable_country_training",
		"enable_direct_dns",
		"enable_dnscache",
		"enable_domain_cache",
		"enable_filecleanup_on_retrieve",
		"enable_filemerge_on_reload",
		"enable_fingerprint_cache",
		"enable_legitrepute_cache",
		"enable_msf",
		"enable_realtime_spf",
		"enable_rules",
		"enable_spamcompiler",
		"enable_spamcompiler_cache",
		"enable_spamcompiler_v5",
		"enable_spf",
		"enable_stat_file",
		"enable_stat_file_upload_thread",
		"enable_training_updates",
		"enable_word_training",
		"extended_rules",
		"extended_rules2",
		"full_training_weight",
		"greylisting_fail_lifetime",
		"greylisting_initial_delay",
		"greylisting_max_entries",
		"greylisting_pass_lifetime",
		"ham_threshold",
		"home_country_list",
		"home_language_list",
		"ignored_domain_list",
		"ignored_ip_list",
		"lbl_list",
		"lbl_skip_list",
		"livefeed",
		"livefeed_min_ttl",
		"max_incr_size",
		"max_word_entries",
		"message_readsize",
		"message_scansize",
		"min_training",
		"msbl_list",
		"msbl_max_domains",
		"msbl_multihit",
		"msbl_threshold",
		"msbl_timeout",
		"msf_bulk_threshold",
		"msf_cleanup_threshold",
		"msf_match_threshold",
		"msf_max_entries",
		"netcheck",
		"netcheck_threshold",
		"nonexistent_user_list",
		"pcre_match_limit",
		"proxy_authtype",
		"proxy_host",
		"proxy_userpwd",
		"rbl_list",
		"rbl_max_ips",
		"rbl_multihit",
		"rbl_threshold",
		"rbl_timeout",
		"regkey",
		"retrieve_incr_only",
		"retrieverules_list",
		"ruleupdate",
		"rule_weights",
		"scan_attachments",
		"sdk_engine_repository",
		"snhost",
		"sntimeout",
		"spambait_user_list",
		"spamcompiler_cache_list",
		"spamcompiler_version",
		"spam_threshold",
		"spf_fail_weight",
		"spf_helo_fail_weight",
		"spf_helo_neutral_weight",
		"spf_helo_none_weight",
		"spf_helo_pass_weight",
		"spf_helo_permerror_weight",
		"spf_helo_softfail_weight",
		"spf_helo_temperror_weight",
		"spf_list",
		"spf_neutral_weight",
		"spf_none_weight",
		"spf_pass_weight",
		"spf_permerror_weight",
		"spf_recursion_depth",
		"spf_softfail_weight",
		"spf_temperror_weight",
		"spoofed_sender_list",
		"stat_file_upload_url",
		"target_throughput",
		"training_write_buffer",
		"use_both_mimesections",
		"use_https",
		"use_score_history",
		"use_score_offsets",
		"verbose",
    "block_non_home_languages",
    "email_alert_address",
    "enable_winsock_error_code"
	};
	
  int rc;
  int size = sizeof(options)/sizeof(char *);
  int i;
  char *extraInfoBuffer=NULL;
  unsigned int extraInfoBufferSize = TMPBUFSIZE;
  unsigned int tmpInfoBufferSize=extraInfoBufferSize;


  fprintf(stdout, "\nCurrent settings:\n");

  extraInfoBuffer = (char *) malloc(extraInfoBufferSize*sizeof(char));
  if (!extraInfoBuffer) {
    fprintf(stdout, "Malloc failed for extraInfoBuffer\n");
    cleanupAndExit(3);
  }
  for (i = 0; i < size; i++) 	{
    while (1) {
      tmpInfoBufferSize=extraInfoBufferSize;
      rc = Mailshell_getOption(engine, options[i], extraInfoBuffer, &tmpInfoBufferSize);
      if (rc == MAILSHELL_OK) {
	fprintf(stdout, "%s = %s\n", options[i], extraInfoBuffer);
	break;
      } else if (rc==MAILSHELL_BUFFER_TOO_SMALL) {
	if (extraInfoBuffer) free(extraInfoBuffer);
	extraInfoBuffer = (char *) malloc(tmpInfoBufferSize*sizeof(char));
	if (!extraInfoBuffer) {
	  fprintf(stdout, "Malloc failed for extraInfoBuffer\n");
	  cleanupAndExit(3);
	}
	extraInfoBufferSize=tmpInfoBufferSize;
      } else {
	fprintf(stdout, "got %d for %s\n", rc, options[i]);
	break;
      }
    }
  }
  if (extraInfoBuffer) free(extraInfoBuffer);
  fprintf(stdout, "\n");
}

void checkFileValidity(char *filepath) {
  int validFormat;
  int rc=1;
  return;
  rc = Mailshell_verifyRuleFileFormat(engine,filepath,&validFormat);
  if (rc==MAILSHELL_OK) {
    if (validFormat) 
      fprintf(stdout, "Rule file %s is correctly formatted\n", filepath);
    else
      fprintf(stdout, "Rule file %s is not in correct format\n", filepath);
  } else if (rc==MAILSHELL_INVALID_ARG) {
    fprintf(stdout, "Rule file could not be verified, invalid arg %s\n", filepath);
  }
}
// display name and size of each rule file
void showRuleFileList(const char *confdir, const char *filetype) {
  char buffer[TMPBUFSIZE];
  char *fname;

#ifdef WIN32
  struct _finddata_t c_file;	
  long hFile;

  char * specifier;
  char *p;
  int length = strlen(confdir);
  strcpy(buffer, confdir);
  buffer[length] = '\\';
	
  strcpy(buffer + length+1, filetype);
  p=buffer+length;
  length = length + strlen(filetype) +1;

  buffer[length] = '.';
  buffer[length+1] = '*';
  buffer[length+2] = 0;

  specifier = buffer;

  if( (hFile = _findfirst(specifier,&c_file))==-1) return;

  do {
    // ignore empty files and directories
    if (c_file.attrib & _A_SUBDIR) continue;
    if (c_file.size == 0) continue;
    fname=c_file.name;
    if (strnicmp(fname, filetype, strlen(filetype)) == 0 &&
	strlen(fname)==strlen(filetype)+25) {
      fprintf(stdout, "found file: %s of size %d\n", fname, c_file.size);
      *p='\\';
      strcpy(p+1,fname);
      checkFileValidity(buffer);
    }
  } while ( _findnext( hFile, &c_file ) == 0 );
  _findclose(hFile);
#else			

  struct dirent *de;
  struct stat statbuf;
  int length=0;
  DIR *thedir = opendir(confdir);
  if (!thedir) return;

  length = strlen(confdir);
  while ((de=readdir(thedir))) {
    fname = de->d_name;
		
    strcpy(buffer, confdir);
    buffer[length] = '/';
		
    strcpy(buffer + length+1, fname);
		
    if (stat(buffer,&statbuf)!=0) continue;
    if (S_ISDIR(statbuf.st_mode)) continue;
    if (statbuf.st_size == 0) continue;
    if (strncasecmp(fname, filetype, strlen(filetype)) == 0 &&
	strlen(fname)==strlen(filetype)+25) {
      fprintf(stdout, "found file: %s of size %ld\n", fname, statbuf.st_size);
      checkFileValidity(buffer);
    }
  }
  if (thedir) closedir(thedir);
#endif
  return;
}

// Cleanup any global resources like handles
void cleanupResources() {
#ifdef WIN32
  if (threadPoolSem) {
    CloseHandle(threadPoolSem);
    threadPoolSem = NULL;
  }
#endif
}

void cleanupAndExit(int exitcode) {
  cleanupResources();
  exit(exitcode);
}
int main (int argc, char **argv) 
{
  threadRec_t *threadRecs;
  int sleeptime=0;
  int bigLoops=1;
  int modbase=10;
  int reportMod=1;
  int i=0;
  int j=0;
  int numInst = 0;
  int rc = 0;
  unsigned int totalMsgs=0;
  char fname[TMPBUFSIZE];
  char vbuf[40];
  unsigned int vbufSize=40;
  const char *confdir = NULL;
  const char *rulesdir = NULL;
  char *msgdir = NULL;
  time_t initStartTime; 
  time_t initEndTime;
  time_t scanStartTime;
  time_t scanEndTime;
  int filesize;
  unsigned totalBytes = 0;
#ifndef WIN32
  pthread_attr_t pta;
  size_t stack_size=0;
#endif

#ifdef WIN32
  unsigned int thrid;
#else
  struct dirent *de;
  struct stat statbuf;
#endif

  char *regkey = NULL;
  char *netcheck = NULL;
  char *retrieverules = NULL;
  char *verbose = NULL;
  char *ruleupdate = NULL;
  char *use_cache = NULL;
  char *sntimeout = NULL;
  char *locale = NULL;

  char *parameters[100]; // stores strings with key=value argument.
  int numParameters = 0; // number of key=value arguments that we found.
  char *splitPositions[100]; // location of equals sign within each string in parameters variable. 
  char *splitPosition;
  char keyName[100];
  char keyValue[TMPBUFSIZE];
  int position;
  char ruleVersionBuffer[64];
  time_t updateTime;
  int totalTmpSize=0;

  programName = argv[0];

  // Parse command line options
  for (i=1; i < argc; i++) {
    char *arg = argv[i];
    if (!strcmp(arg,"-D")) {
      i++;
      if (i>=argc) usage();
      confdir = argv[i];
    } else if (!strcmp(arg,"-R")) {
      i++;
      if (i>=argc) usage();
      rulesdir = argv[i];
    } else if (!strcmp(arg,"-b")) {
      i++;
      if (i>=argc) usage();
      msg_bufsize = atoi(argv[i]);
    } else if (!strcmp(arg,"-t")) {
      i++;
      if (i>=argc) usage();
      numThreads = atoi(argv[i]);
    } else if (!strcmp(arg,"-s")) {
      i++;
      if (i>=argc) usage();
      sleeptime = atoi(argv[i]);
    } else if (!strcmp(arg,"-l")) {
      i++;
      if (i>=argc) usage();
      bigLoops = atoi(argv[i]);
    } else if (!strcmp(arg,"-m")) {
      i++;
      if (i>=argc) usage();
      modbase = atoi(argv[i]);
    } else if (!strcmp(arg,"-r")) {
      i++;
      if (i>=argc) usage();
      reportMod = atoi(argv[i]);
    } else if (!strcmp(arg,"-v") || !strcmp(arg, "-showstatus")) {
      showMsgScore=1;
    } else if (!strcmp(arg, "-regkey")) {
      i++;
      regkey = argv[i];
    } else if (!strcmp(arg, "-locale")) {
      i++;
      locale = argv[i];
    } else if (!strcmp(arg, "-netcheck")) {
      i++;
      netcheck = argv[i];
    } else if (!strcmp(arg, "-retrieverules")) {
      i++;
      retrieverules = argv[i];
    } else if (!strcmp(arg, "-smtpip")) {
      i++;
      smtpip = argv[i];
    } else if (!strcmp(arg, "-smtpenvelope")) {
      i++;
      smtpenvelope = argv[i];
    } else if (!strcmp(arg, "-verbose")) {
      i++;
      verbose = argv[i];
    } else if (!strcmp(arg, "-ruleupdate")) {
      i++;
      ruleupdate = argv[i];
    } else if (!strcmp(arg, "-use_cache")) {
      i++;
      use_cache = argv[i];
    } else if (!strcmp(arg, "-sntimeout")) {
      i++;
      sntimeout = argv[i];
    } else if (!strcmp(arg,"-g")) {
      doGreylistCheck=1;
    } else {
      splitPosition = strchr(argv[i], '=');
      if (splitPosition != NULL && numParameters < 100) {
	parameters[numParameters] = argv[i];
	splitPositions[numParameters] = splitPosition; // save off to avoid searching again.
	numParameters++;
      }
      msgdir = argv[i];
    }
  }
  if (confdir==NULL) {
    confdir = ".";
  }

  if (locale!=NULL) {
    fprintf(stdout, "setlocale(LC_ALL, %s)\n",locale);
    setlocale(LC_ALL,locale);
  }

  if (!rulesdir && confdir) {
    rulesdir = confdir;
  }
#ifdef WIN32
  threadPoolSem = CreateSemaphore(
				  NULL,   // no security attributes
				  numThreads,   // initial count
				  numThreads,   // maximum count
				  NULL);  // unnamed semaphore

#else
  threadPoolSem = (sem_t *) malloc(sizeof(sem_t));
  sem_init(threadPoolSem,0,numThreads);
#endif

  threadRecs = (threadRec_t *) malloc(numThreads*sizeof(threadRec_t));
  for(j=0; j<numThreads; j++) {
    threadRecs[j].busy=0;
    threadRecs[j].index=j;
    threadRecs[j].fname=NULL;
    threadRecs[j].thr=0;
  }

  // Initialize Score Array
  for(j=0; j<=100; j++) {
    allScores[j]=0;
  }

  // Initialize Elapsed Time Array
  for(j=0; j<1001; j++) {
    allTimes[j]=0;
  }

  // Initialize Kilobytes/Second Time Array
  for(j=0; j<1001; j++) {
    allKbs[j]=0;
  }

  if (!msgdir) {
    usage();
  }


  time(&initStartTime);
  fprintf(stdout,"current time is: %s\n",ctime(&initStartTime));
	
  fprintf(stdout,"Instantiating engine\n");

  engine = Mailshell_constructor(confdir);

  if (regkey != NULL)
    Mailshell_setOption(engine,"regkey", regkey);

  if (netcheck != NULL)
    Mailshell_setOption(engine,"netcheck", netcheck);

  if (ruleupdate != NULL)
    Mailshell_setOption(engine,"ruleupdate", ruleupdate);

  if (verbose != NULL)
    Mailshell_setOption(engine,"verbose", verbose);

  if (sntimeout != NULL)
    Mailshell_setOption(engine,"sntimeout", sntimeout);

  if (use_cache != NULL)
    Mailshell_setOption(engine,"use_cache", use_cache);



#ifndef WIN32
  // Ensure that thread stack size is at least 1MB
  // FreeBSD has a default thread stack size of 64KB which can be too small
  pthread_attr_init(&pta);
  pthread_attr_getstacksize(&pta,&stack_size);
  if (stack_size < MIN_THREAD_STACK_SIZE) {
    fprintf(stdout,"Adjusting minimum thread stack size from %lu bytes to %d bytes\n\n",stack_size,MIN_THREAD_STACK_SIZE);
    stack_size = MIN_THREAD_STACK_SIZE;
    pthread_attr_setstacksize(&pta,stack_size);
  }
#endif

  // parse the key=value arguments and apply the options
  Mailshell_setOption(engine,"enable_disk_mode", "yes");
  for (i = 0; i < numParameters; i++) {
    position =  splitPositions[i]  - parameters[i];
    if (position > 0 && position < 99)
      {
	strncpy(keyName, parameters[i], position);
	keyName[position] = 0;
	position = strlen(parameters[i]) - position;
	if (position > 299) {
	  position=299;
	}
	strncpy(keyValue, splitPositions[i] + 1,  position);
	keyValue[position] = 0;

	rc = Mailshell_setOption(engine, keyName, keyValue);
	fprintf(stdout, "Setting option :%s: to :%s:, rc %d\n", keyName,keyValue,rc);

	if (rc == MAILSHELL_INVALID_OPTION_KEY) {
	  fprintf(stdout, "invalid option %s\n", keyName);
	  cleanupAndExit(0);
	}
	else if (rc == MAILSHELL_INVALID_OPTION_VALUE) {
	  fprintf(stdout, "invalid option value %s\n", keyValue);
	  cleanupAndExit(0);
	}
      }
  }
  Mailshell_reloadOptions(engine);
  // determine Mailshell SDK version
  if (Mailshell_getVersion(engine,&vbuf[0], &vbufSize)==MAILSHELL_OK) {
    fprintf(stdout,"SDK version: %s\n",vbuf);
  }

  fprintf(stdout,"\nSetting ruleUpdateCallbackFunction with opaque pointer %p\n",engine);

  Mailshell_setRuleUpdateCallback(engine,&ruleUpdateNotification,(void *)engine);
  Mailshell_setRetrieveRuleProgressCallback(engine,&ruleRetrieveProgress,(void *)engine);

  if (retrieverules==NULL || retrieverules[0]=='y') {
    fprintf(stdout,"\nChecking for rule updates . . . \n");
    rc = Mailshell_retrieveRules(engine,rulesdir);
    if (rc==MAILSHELL_OK) {
      fprintf(stdout,"Done updating rules, rc is %d\n",rc);
    } else if (rc==MAILSHELL_RULES_UPTODATE) {
      fprintf(stdout,"Rules already up-to-date, rc is %d\n",rc);
    } else {
      fprintf(stdout,"Error updating rules, rc is %d\n",rc);
    }
  }
  //rc = Mailshell_setOption(engine, "prodcode", "7");
  //if (rc != MAILSHELL_OK)
  //{
  //fprintf(stderr, "Invalid product code\n");
  //}
  
  time(&initStartTime);
  fprintf(stdout,"\nInitializing Mailshell SpamCatcher . . . %s\n",ctime(&initStartTime));
  rc=0;
  rc = Mailshell_initialize(engine);
  switch(rc) {
  case MAILSHELL_OK:
    break;
  case MAILSHELL_LICENSE_INVALID:
    fprintf(stdout,"ERROR: Mailshell License is invalid.\n");
    cleanupAndExit(6);
    break;
  case MAILSHELL_LICENSE_EXPIRED:
    fprintf(stdout,"ERROR: Mailshell License is expired.\n");
    cleanupAndExit(6);
    break;
  case MAILSHELL_INVALID_CONFIG_DIR:
    fprintf(stdout,"ERROR: Invalid Configuration Directory.\n");
    cleanupAndExit(6);
    break;
  case MAILSHELL_NO_RULES_LOADED:
    fprintf(stdout,"ERROR: No Rules Loaded.\n");
    cleanupAndExit(6);
    break;
  default: 
    fprintf(stdout,"ERROR: Unknown Error occured.\n");
    cleanupAndExit(6);
    break;
  }

  time(&initEndTime);
  fprintf(stdout,"initialization completed at: %s\n",ctime(&initEndTime));
  fprintf(stdout,"\nReloading rules in directory :%s: . . . \n",rulesdir);
  rc = Mailshell_reloadRules(engine,rulesdir);
  fprintf(stdout,"Done reloading rules, RC is %d\n",rc);

  if (showMsgScore) {
    showCurrentOptions();

    showRuleFileList(confdir, "sc1.bin");
    showRuleFileList(confdir, "sc2.bin");
    showRuleFileList(confdir, "sc3.bin");
    showRuleFileList(confdir, "sc4.bin");
    showRuleFileList(confdir, "sc5.bin");
    showRuleFileList(confdir, "sc6.bin");
    showRuleFileList(confdir, "sc7.bin");
    showRuleFileList(confdir, "sc8.bin");
    showRuleFileList(confdir, "sc9.bin");
    showRuleFileList(confdir, "sc10.bin");
    showRuleFileList(confdir, "sc11.bin");
    showRuleFileList(confdir, "sc12.bin");
    showRuleFileList(confdir, "sc13.bin");
    showRuleFileList(confdir, "sc14.bin");
    showRuleFileList(confdir, "sc15.bin");
    showRuleFileList(confdir, "sc16.bin");
    showRuleFileList(confdir, "sc17.bin");
    showRuleFileList(confdir, "sc18.bin");
    showRuleFileList(confdir, "sc19.bin");
    showRuleFileList(confdir, "sc21.bin");
    showRuleFileList(confdir, "sc23.bin");
    fprintf(stdout, "\n");
  }

  totalMsgs=0;



  // Display rule file signatures
  for (i=0; i <= 23; i++) {
    rc = Mailshell_getRuleVersion(engine,i,ruleVersionBuffer);
    fprintf(stdout,"Rule Index %d, rc %d, version :%s:\n",i,rc,ruleVersionBuffer);
  }
    
  // Display last rule update time
  rc = Mailshell_getLastRuleUpdateTime(engine,&updateTime);
  fprintf(stdout,"Last Rule Update Time, rc is %d, :%s:\n",rc,ctime(&updateTime));
    
  time(&scanStartTime);
  for (i=0;  i <bigLoops; i++) {
#ifdef WIN32
    struct _finddata_t c_file;
    long hFile;
    char specifier[TMPBUFSIZE];
    _snprintf(specifier,sizeof(specifier),"%s\\*.*",msgdir);

    if( (hFile = _findfirst(specifier,&c_file))==-1) {
      fprintf(stdout, "ERROR: no messages found. \n");
      continue;
    }

    while( _findnext( hFile, &c_file ) == 0 )
      {
	int threadIndex=-1;
	if (c_file.attrib & _A_SUBDIR) 
	  continue;
			
	_snprintf(fname,sizeof(fname),"%s\\%s",msgdir,c_file.name);
	filesize = c_file.size;
#else			
	DIR *thedir = opendir(msgdir);
	if (!thedir) {
	  fprintf(stdout, "ERROR: no messages found. \n");
	  continue;
	}
	while (de=readdir(thedir)) {
	  int threadIndex=-1;
			
	  snprintf(fname,sizeof(fname),"%s/%s",msgdir,de->d_name);
			
	  if (stat(fname,&statbuf)!=0) continue;
	  if (S_ISDIR(statbuf.st_mode)) continue;
	  filesize = statbuf.st_size;
			
#endif
	  while (threadIndex==-1) {
#ifdef WIN32
	    WaitForSingleObject(threadPoolSem, INFINITE);
#else
	    sem_wait(threadPoolSem);// Wait if all threads busy
#endif
	    // Find the first unbusy thread
	    threadIndex  = findUnbusy(threadRecs,numThreads);
#ifdef WIN32
	    if (threadIndex==-1) ReleaseSemaphore(threadPoolSem, 1, NULL);
#else
	    if (threadIndex==-1) sem_post(threadPoolSem);
#endif
	  }
	  if (modbase!=0 && totalMsgs%modbase==0 && totalMsgs!=0) {
	    fprintf(stdout,"Progress Meter: %d Messages\n",totalMsgs);
	  }
			
	  // Re-Claim prior resources
	  if (threadRecs[threadIndex].thr != 0) {
#ifdef WIN32
	    WaitForSingleObject(threadRecs[threadIndex].thr, INFINITE);
	    CloseHandle(threadRecs[threadIndex].thr);
#else
	    pthread_join(threadRecs[threadIndex].thr, NULL);
#endif
	    threadRecs[threadIndex].thr=0;
	  }
	  totalMsgs++;
	  totalBytes += filesize;
			
	  threadRecs[threadIndex].busy=1;
	  threadRecs[threadIndex].filesize=filesize;
	  if (threadRecs[threadIndex].fname) {
	    free(threadRecs[threadIndex].fname);
	    threadRecs[threadIndex].fname=NULL;
	  }
	  threadRecs[threadIndex].fname=strdup(fname);
#ifdef WIN32
	  threadRecs[threadIndex].thr = (HANDLE)_beginthreadex(NULL, 0, ScoreFileWrapper, 
							       (void *)&threadRecs[threadIndex], 0, 
							       &thrid); 
#else
	  rc = pthread_create(&(threadRecs[threadIndex].thr), &pta,
			      scoreFile, 
			      (void *)&threadRecs[threadIndex]);
	  if (rc!=0) {
	    printf("pthread_create failed with error %d\n",rc);
	    threadRecs[threadIndex].busy=0;
	    sem_post(threadPoolSem);
	  }
#endif
	}
#ifdef WIN32
	_findclose( hFile );
#else
	closedir(thedir);
#endif
        if (sleeptime>0) {
          fprintf(stdout,"Done with loop %d, now sleeping for %d seconds\n",i,sleeptime);
#ifdef WIN32
          Sleep(sleeptime);
#else
          sleep(sleeptime);
#endif
        }
      }
    // Wait for all threads
    for (i=0; i < numThreads; i++) {
      if (threadRecs[i].thr != 0) {
#ifdef WIN32
	WaitForSingleObject(threadRecs[i].thr, INFINITE);
	CloseHandle(threadRecs[i].thr);
#else
	pthread_join(threadRecs[i].thr,NULL);
#endif
	threadRecs[i].thr = 0;
	if (threadRecs[i].fname) {
	  free(threadRecs[i].fname);
	  threadRecs[i].fname=NULL;
	}
      }
    }
    time(&scanEndTime);
    if (engine) Mailshell_destructor(engine);
    engine=NULL;
	
    showStats(totalMsgs,reportMod,totalBytes,&initStartTime,&initEndTime,&scanStartTime,&scanEndTime, verbose);

    if (threadRecs) free(threadRecs); threadRecs=NULL;
    cleanupAndExit(0);
    return 0;
  }

